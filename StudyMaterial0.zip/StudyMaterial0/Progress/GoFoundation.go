package main

import (
	"fmt"
	"os"
	"strings"
	"flag"
)

//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

// Function Which Takes No Argument And Doesn't Return Anything
func helloWorld() {
	fmt.Println("Hello World!!!")
}

// Global Constant Value
const boilingPointF = 212.0 

// Farenhite To Centrigrate Function
// Function Which Takes One Argument And Return One Value
//	 	Argument and Return Type is float64
func fToC( f float64 ) float64 {
	return ( f - 32 ) * 5 / 9 
}

func playWithConstantVariables() {
	var f = boilingPointF
	var c = ( f - 32 ) * 5 / 9

	//			Format String Having Format Specifiers
	// Format Specifiers Are Place Holders Where Value Will Be Substituted
	fmt.Printf("Boilding Point: %g, Farenheit Or Centrigrate : %g\n", f, c)
	const freezingF, boildingF = 32.0, 212.0 // Local To Function Context

	// Invoking/Calling Function fToC()
	fmt.Printf("%g Farenheit Or %g Centrigrate\n" , freezingF, fToC( freezingF ))	
	fmt.Printf("%g Farenheit Or %g Centrigrate\n" , boildingF, fToC( boildingF ))	
}

//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

// Design Thinking Style

func playWithDataTypes() {
	// To Create Your Code Safe
	// Go Will Initialise To Default Values
	//		Zeros Of Corresponding Types
	//	bool Type Zero Is false Value
	//	int Type Zero Is 0 Value
	//	float64 Type Zero Is 0.0 Value
	//	string Type Zero Is "" Value
	var c, python, java bool
	var i int

	// Multiple Values Initialisation
	var ii, jj int = 10, 20

	// Compiler Will Do Following At Compile Time
	// 1. Infer Type From RHS Values
	// 2. Bind Inferred Type With LHS Identifiers	
	var iii, jjj = 10, 20

	var iiii, jjjj int

	// Short Cut Notations
	// Python Style
	k := 3
	some, some1, something := true, false, "Good!"
	
	// What Will Be Output???
	fmt.Println(c, python, java, i)
	// false false false 0
	fmt.Println( ii, jj )
	fmt.Println( iii, jjj )
	fmt.Println( iiii, jjjj )

	fmt.Println( k, some, some1, something )

	// var u int16 = 10
	// var v int32 = 100

	// Go Is Strict Tyep System
	// invalid operation: u * v (mismatched types int16 and int32)
	// var z = u * v 
}

//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

// Naming Conventions For Identifiers
//		Generally Identifiers Follows Camel Cases With First Word In Small

//		Identifiers First Alphabet Is Small
//			These Are Locals/Private To Pacakage
//		Identifiers First Alphabet Is Capital
//			These Are Exported From Pacakage

// Celsius And Fahrenheit Are Type Aliases Of float64
// 		Type Aliases Can Be Used Wherever float64 Used
//		Creating It To Express Domain Knolegedge
//		To Improve Code Readibility

// Creating Two Types Viz Celsius And Fahrenheit
type Celsius 	float64
type Fahrenheit float64

func FToC( f Fahrenheit ) Celsius { return Celsius( ( f - 32) * 5 / 9 )  }
func CToF( c Celsius ) Fahrenheit { return Fahrenheit( ( c * 9/5) + 32 )  }

const ( // Definining Multiple Constants
	BoilingC  		Celsius = 100.0
	FreezingC   	Celsius = 0
	AbsoluteZeroC 	Celsius = -273.15
	FreezingF 		Fahrenheit = 0.0
)

func playWithConstants() {
	fmt.Printf("\n %g", BoilingC + FreezingC )
	
	boilingF := CToF( BoilingC )

	fmt.Printf("\n %g", boilingF - CToF( FreezingC ) )	
	fmt.Printf("\n %g", boilingF )

	// Type Safety Guarnteed Due To Strict Type System
	// Compilation Error boilingF + FreezingC (mismatched types Fahrenheit and Celsius)
	// fmt.Printf("\n %g",  boilingF + FreezingC )	
}

//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func playWithForLoop( args []string ) {
	var s, sep string

	fmt.Printf("Command Line Arguments Count: %d" , len( args ) )

	sep = "\n"
	for i := 0 ; i < len( args ) ; i++ {
		s += sep + args[i]
	}

	fmt.Println( s )
}

// go run GoFoundation.go -n true -s "###"
// Function : playWithForLoop
// Command Line Arguments Count: 5
// /tmp/go-build3180275770/b001/exe/GoFoundation
// -n
// true
// -s
// ###

//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func playWithFlagPackage() {
	var n = flag.Bool("n", false, "Omit Trailing New Line...")
	var sep = flag.String("s", " ", "String Seperator...")

	flag.Parse()
	fmt.Print( strings.Join( flag.Args(), *sep ) )

	if !*n {
		fmt.Println()
	}
}
// go run GoFoundation.go -n true -s "###"
// Function : playWithFlagPackage
// true -s ###

//___________________________________________________________________


func playWithFormatSpecifiers() {
	c := FToC(212.0)

	fmt.Println(c)

	fmt.Printf("\n %v", c)
	fmt.Printf("\n %f", c)
	fmt.Printf("\n %g", c)
	fmt.Printf("\n %e", c)
}

// Function : playWithFormatSpecifiers
// 100

//  100
//  100.000000
//  100
//  1.000000e+02


// General:
// %v	the value in a default format
// 			when printing structs, the plus flag (%+v) adds field names
// %#v	a Go-syntax representation of the value
// %T	a Go-syntax representation of the type of the value
// %%	a literal percent sign; consumes no value

// Boolean:

// %t	the word true or false
// Integer:

// %b	base 2
// %c	the character represented by the corresponding Unicode code point
// %d	base 10
// %o	base 8
// %O	base 8 with 0o prefix
// %q	a single-quoted character literal safely escaped with Go syntax.
// %x	base 16, with lower-case letters for a-f
// %X	base 16, with upper-case letters for A-F
// %U	Unicode format: U+1234; same as "U+%04X"

// Floating-point and complex constituents:

// %b	decimalless scientific notation with exponent a power of two,
// 	in the manner of strconv.FormatFloat with the 'b' format,
// 	e.g. -123456p-78
// %e	scientific notation, e.g. -1.234456e+78
// %E	scientific notation, e.g. -1.234456E+78
// %f	decimal point but no exponent, e.g. 123.456
// %F	synonym for %f
// %g	%e for large exponents, %f otherwise. Precision is discussed below.
// %G	%E for large exponents, %F otherwise
// %x	hexadecimal notation (with decimal power of two exponent), e.g. -0x1.23abcp+20
// %X	upper-case hexadecimal notation, e.g. -0X1.23ABCP+20
// String and slice of bytes (treated equivalently with these verbs):

// %s	the uninterpreted bytes of the string or slice
// %q	a double-quoted string safely escaped with Go syntax
// %x	base 16, lower-case, two characters per byte
// %X	base 16, upper-case, two characters per byte
// Slice:

// %p	address of 0th element in base 16 notation, with leading 0x
// Pointer:

// %p	base 16 notation, with leading 0x
// The %b, %d, %o, %x and %X verbs also work with pointers,
// formatting the value exactly as if it were an integer.


// REFERENCE LINK : https://pkg.go.dev/fmt

//___________________________________________________________________



//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func main() {
	fmt.Println("\nFunction : helloWorld")
	helloWorld()

	fmt.Println("\nFunction : playWithConstantVariables")
	playWithConstantVariables()

	fmt.Println("\nFunction : playWithDataTypes")
	playWithDataTypes()

	fmt.Println("\nFunction : playWithConstants")
	playWithConstants()

	fmt.Println("\nFunction : playWithForLoop")
	playWithForLoop( os.Args )

	fmt.Println("\nFunction : playWithFlagPackage")
	playWithFlagPackage()

	fmt.Println("\nFunction : playWithFormatSpecifiers")
	playWithFormatSpecifiers()

	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")	
}

