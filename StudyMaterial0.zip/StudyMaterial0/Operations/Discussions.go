_____________________________________________________________

The C Programming Language, 2nd Edition,
	By Kernigham and Dennis Ritchie

_____________________________________________________________


Go Keywords
_____________________________________________________________
25 Keywords Language


Go Predefined Names
_____________________________________________________________

Constants: 
true false iota nil

Types:
int   ???? 
uint  ????

int8 [ -128, 127 ]
int16 [ -32768, 32767 ] 

int32 
int64

uint8 [ 0, 255 ] 
uint16 [0, 65535 ]

uint32 
uint64 

uintptr 

float32 float64 complex64 complex128  
bool byte rune string error

Functions:

make len cap new append copy 
close delete complex real imag
panic recover

_____________________________________________________________

Go Numeric types
_____________________________________________________________

An integer, floating-point, or complex type represents the set of integer, floating-point, or complex values, respectively. They are collectively called numeric types. 

The predeclared Architecture-Independent numeric types are:

uint8       the set of all unsigned  8-bit integers (0 to 255)
uint16      the set of all unsigned 16-bit integers (0 to 65535)
uint32      the set of all unsigned 32-bit integers (0 to 4294967295)
uint64      the set of all unsigned 64-bit integers (0 to 18446744073709551615)

int8        the set of all signed  8-bit integers (-128 to 127)
int16       the set of all signed 16-bit integers (-32768 to 32767)
int32       the set of all signed 32-bit integers (-2147483648 to 2147483647)
int64       the set of all signed 64-bit integers (-9223372036854775808 to 9223372036854775807)

The predeclared integer types with implementation-specific sizes:
	
uint     either 32 or 64 bits
int      same size as uint

BEST PRACTICE : Always Prefer Platform Independent Types Over Platform Dependent Types



_____________________________________________________________
// PLEASE RAISE YOUR HAND WHOEVER DONE IT!


Write Code For sum Function With Following Signature In C/C++?

// 	BAD CODE	
	int sum(int x, int y) {
		return x + y;
	}

_____________________________________________________________
// PLEASE RAISE YOUR HAND WHOEVER DONE IT!


Write Code For sum Function With Following Signature In C/C++?
	
	Which Will Return Valid Aritmatic Sum Of Two Integers
	Otherwise Print Can't Calculate For Given X And Y Values

	int sum( int x, int y ) {
	

	}

_____________________________________________________________
// PLEASE RAISE YOUR HAND WHOEVER DONE IT!

// GOOD DESIGN
// 		CHECK AND REASON FOLLOWING DESIGN

	#include <limits.h>

	// Following Code Is Platform Independent!
	// Type Safe Code
	signed int sum(signed int si_a, signed int si_b) {
		  signed int sum = 0;
		  if (((si_b > 0) && (si_a > (INT_MAX - si_b))) ||
		      ((si_b < 0) && (si_a < (INT_MIN - si_b)))) {
			    printf("\nCan't Calculate Sum For Given Values");
		  } else {
			    sum = si_a + si_b;
			  	return sum;
		  }
	}

_____________________________________________________________

	
16:39:45 From Sagar Sharma To Everyone:

// DESGIN 1
// Time Complexity Is O( n )		

	#include <stdio.h>	
	int sum(int a, int b){
	    if(b>0){
	        while (b > 0) {
	            a++;
	            b--;
	        }
	    }
	    if(b<0){
	        while (b < 0) {
	            a--;
	            b++;
	        }
	    }
	    return a;
	}
	
	int main(){
	    printf("%d\n",sum(2147483647,2147483647));
	    return 0;
	}


16:40:18 From Akhand Singh To Everyone:

// DESGIN 2

	int sum(int x, int y) {
	    int max = 2147483640;
	
	    // x - y > max Is Always False Condition
	    if (max < (x - y) )
	       return "can't calculate"
	    else {
	    	return x+y
	    }
	}



16:41:22 From Sujay Ramesh To Everyone:
	
// BAD LOGIC	
	int sum(int x, int y) {
	    // check the input range if it 
	    if ((x + y) < 0 ) {
	        printf("Cannot calculate sum.");
	        return 0;
	    }
	    return x+y;
	}


16:44:20 From Sajeesh To Everyone:
	
	import "fmt"
	
	func main() {
	    res := sum(-12, 12)
	    fmt.Println(res)
	}

// BAD LOGIC	
	func sum(x, y int) int {	    
	    if x < 0 || y < 0 {
	        fmt.Println("Cannot calculate Sum")
	        return 0
	    } else {
	        return x + y
	    }
	}


16:45:15 From Deepa Joy To Everyone:

// DESGIN 3
//		Hardware Dependent

	int sum(int x, int y) {
		r = ( x + y )
		if  ((x > 0) && (y > 0) && (r < 0 )) || ( (x <0) && (y < 0) && (r > 0) ) { 
				printf("Cannot calculate sum.");
	        	return 0; 
	    } else { 
	    	return r; 
	    }
	}


16:47:08 From Unais Arakkal To Everyone:

	int sum(int x, int y) { 
		res = x+y;

// You Can't Access Type Information In Runtime In C		
		if (type(x) == int && type(y) == int) {
			return res
		} else {
			retun 0
		}
	}


16:48:01 From Soni Kumari To Everyone:

	func sum(a, b int) int {

// BAD LOGIC	    
	    if a < 0 || b < 0 {
	        fmt.Println("Sum is missing")
	        return 0
	    } else {
	        return a + b
	    }
	}


16:48:24 From Sudharsan T.C.M To Everyone:
	
	int sum (int x ,int y) {
	    int max=2147483647
	    int min=-2147483647
	
	    // Always TRUE Condition
	    if (x < max) && (y < max) && (x > min) && (y > min)
	    {
	        if ((x+y) > max) && ((x+y) < min)
	        {
	        	printf ("Operation not possible")
	        }
	        else {
	        	int z;
	        	z = x+y;
	        	return z
	        }
	    } else { // DEAD CODE
	    	printf ("Operation not possible")
	    }    
	}


16:49:20 From Saneen To Everyone:
	
	func sum(x, y int) int {

//	BAD LOGIC	    
	    if x < 0 || y < 0 {
	
	        fmt.Println("Not possible")
	        
	    } else {
	
	        return x + y
	    }
	}


16:49:58 From Palash Agarwal To Everyone:

// DESIGN 3	
	// GOOD DIRECTION

	sum(x,y) {
		res = x+y
		if(x>0 && y>0 && (x > INT_MAX-y)) 
			return (can't calculate sum)
		else if(x<0 && y<0 && (x < INT_MIN-y)) 
			return (can't calculate sum)
		else 
			return (x+y)
	}

16:51:06 From Chandan Singh To Everyone:
	int sum(int x, int y){
		int r =0;
		r = x+y;
	
		// Always False Condition
		if (r <  -2147483647){
			printf("Not valid");
	
		}
		else{
			return r;
		}
	}

16:51:57 From Devasena Ekanathan To Everyone:
	
// BAD LOGIC
	Sum(int a, int b)
	{
	if (a > INT_MAX - b)
		printf(“operation not supported”);
	else {
		printf( a + b);
	}


16:53:12 From Narottam Kumar To Everyone:

	int sum(int x, int y) {

		// 
		long int s = 0
		// BAD DESIGN
		if( s < -2147483648  or s > 2147483647){
			printf("Not able to add");
		}
		else{
			return (s); // 
		}


16:55:05 From Arnav Anand To Everyone:
	
// LOGIC IS NOT COMPLETE
	int sum(int a, int b) {
	    int overflow=0; 
	    if (b> INT_MAX-a ) overflow=1;
	    else if (a>INT_MAX-b) overflow=1;
	    if(overflow==1)
	        printf("error");
	    else 
	        return a+b;
	}

_____________________________________________________________
_____________________________________________________________
_____________________________________________________________
_____________________________________________________________
_____________________________________________________________
_____________________________________________________________
_____________________________________________________________
_____________________________________________________________
_____________________________________________________________
_____________________________________________________________
_____________________________________________________________
