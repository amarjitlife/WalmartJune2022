__________________________________________________________
Go Environment Preparation
__________________________________________________________

1. Go Compiler Download : https://go.dev/dl/

2. Install Go Compiler

3. Create Hello.go File With Following Code

		package main

		import "fmt"

		func main() {
			fmt.Println("Hello World!!!")
		}

	Save Hello.go File In YOUR_PATH/Documents/GoTraining

4. Run Hello.go Code

	4.0 Open Command Prompt Or Terminal Application 
	
	4.1 Change Directory To
		YOUR_PATH/Documents/GoTraining

	4.2 Run Hello.go With Following Command
		go run Hello.go
__________________________________________________________

OR 
__________________________________________________________

Use Go Cloud Lab Environment
__________________________________________________________

PLEASE RAISE YOUR HAND! MOMENT YOU ARE DONE!!!
__________________________________________________________
