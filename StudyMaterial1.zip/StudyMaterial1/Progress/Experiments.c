
#include <stdio.h> 
#include <stdbool.h>
#include <limits.h>


void playWithDataTypes() {
	// Original C =
	// Following Identifiers Are Assigned Garbage Value
	// 		Local Variables Are Automatic In C/C++
	bool c, python, java;

	// Best Practice
	//		Always Initialise Variables/Constants To Legal Value
	int i;

	// What Will Be Output???
	printf("\n%d %d %d %d\n", c, python, java, i);
	// 0 0 0 0

	// false false false 0
}

// Choices Are: 1. CTE, 2. RTE, 3. If Block 4. Else Block
void playWithIfElse() {
	int x = -10;

	// if (expression)
	//		expression Evalutates To Non Zero int Value Than It's True
	//		Otherwise False
	if( x ) { printf("If Block"); }
	else  	{ printf("Else Block"); }
}


// Why C/C++ Designers Selected Following Desing
//		char Doesn;t Have Default Range, It's Platform/Hardware Dependent


void playWithCharType() {
	// Depends On Range Of char Type
	//		Char Range Can Be [0, 255] Unsigned Range Or 
	//		[-128 to 127] Signed Range
	//		char Doesn;t Have Default Range, It's Platform/Hardware Dependent
	char ch = 0; // [-128 to 127 ]

	// int Type Range
	// Signed [ -32768, 32767 ]
	// UnSigned [ 0, 65535 ]
	int i; // Default Signed [ -32768, 32767 ]

	// Output Of Following Loop Is Indeterminate
	// 		Can Be Infinite Loop
	//		or Finite Loop
	// for( ; ch < 255 ; ch++ ) {
	// 	printf("Ch value: %c %d\n", ch, ch);
	// }

	// unsigned char ch1 = 0;
	// for( ; ch1 < 128 ; ch1++ ) {
	// 	printf("Ch1 value: %c %d\n", ch1, ch1);
	// }	
}

void playWithDataTypesAgain() {
	int i = 100;
	long l = 900;

	long ll = l + i;

	printf(" \nResult : %ld", ll);
}

//___________________________________________________


int sum(int x, int y) {
	return x + y;
}

void playWithSum() {
	int x = 2147483647;
	int y = 2;

	int z = x + y;
	printf( "\nResult : %d\n", z );

	int xx = -2147483647;
	int yy = -2;

	int zz = xx + yy;
	printf( "Result : %d\n", zz );

}

// Function : playWithSum
// Result : -2147483647
// Result : 2147483647

//___________________________________________________


// Following Code Is Platform Independent!

//
// Type Safe Code
//		Repspecting Type Definition Like God!
signed int summation(signed int si_a, signed int si_b) {
	  signed int sum = 0;
	  if (((si_b > 0) && (si_a > (INT_MAX - si_b))) ||
	      ((si_b < 0) && (si_a < (INT_MIN - si_b)))) {

		    printf("\nCan't Calculate Sum For Given Values");
	  
	  } else {
		    sum = si_a + si_b;
		  	return sum;
	  }
}

//___________________________________________________

void playWithStrings() {
	// There Is No String Type In C
	// String Value Starts With " And Ends With "
	// String Is Sequence Of ASCII Characters
	// In C
	//		String Follows ASCII Coding

	char greeting[] = "Good Morning!";	
	char *greetingAgain = "Good Morning!";

	printf("\nGreeting : %s", greeting );

	for ( int i = 0 ;  greeting[i] != '\0' ; i++ ) {
		printf("\nGreeting Character: %c", greeting[i] );
	}
}


//___________________________________________________
//___________________________________________________
//___________________________________________________
//___________________________________________________

int main() {
	printf("\nFunction : playWithDataTypes");
	playWithDataTypes();

	printf("\nFunction : playWithIfElse");
	playWithIfElse();

	printf("\nFunction : playWithCharType");
	playWithCharType();

	printf("\nFunction : playWithDataTypesAgain");
	playWithDataTypesAgain();

	printf("\nFunction : playWithSum");
	playWithSum();

	printf("\nFunction : playWithStrings");
	playWithStrings();

	// printf("\nFunction : ");
	// printf("\nFunction : ");
	// printf("\nFunction : ");
	// printf("\nFunction : ");
	// printf("\nFunction : ");
	// printf("\nFunction : ");
	// printf("\nFunction : ");
	// printf("\nFunction : ");
	// printf("\nFunction : ");
	// printf("\nFunction : ");
}

