
_____________________________________________________________

DAY 01 : ASSIGENMENTS
_____________________________________________________________

	READING ASSIGNMENT
		Recommended By Trainer
		The C Programming Language, 2nd Edition,
			By Kernigham and Dennis Ritchie

	PHASE I : 
		1. ARRAYS AND POINTERS [ MUST MUST ]

	PHASE II : 
		1. FIRST 6 CHAPTERS

_____________________________________________________________

DAY 02 :
_____________________________________________________________


_____________________________________________________________

DAY 03 :
_____________________________________________________________

	READING ASSIGNMENT
		Recommended By Trainer
		The C Programming Language, 2nd Edition,
			By Kernigham and Dennis Ritchie

	PHASE I : 
		1. ARRAYS AND POINTERS [ MUST MUST ]

_____________________________________________________________

DAY 04 :
_____________________________________________________________


_____________________________________________________________

DAY 05 :
_____________________________________________________________



// __________________________________________________________
//
//				REFERENCE MATERIAL TO FOLLOW
// __________________________________________________________

	Level 0 Book

		REFERENCE : THE C PROGRAMMING LANGUAGE
			By Kernigham and Denish Rithie
			https://kremlin.cc/k&r.pdf

	Level I Book
		
		Learning Go: An Idiomatic Approach to Real-World Go Programming 1st Edition
		by Jon Bodner

		https://www.amazon.com/Learning-Go-Idiomatic-Real-World-Programming/dp/1492077216

	Level II Book
		
		Go Programming Language, The (Addison-Wesley Professional Computing Series) 1st Edition
		by Alan Donovan  (Author), Brian Kernighan (Author)

		https://www.amazon.com/Programming-Language-Addison-Wesley-Professional-Computing

	Level III Book
		
		Concurrency in Go: Tools and Techniques for Developers 1st Edition
		by Katherine Cox-Buday

		https://www.amazon.com/Concurrency-Go-Tools-Techniques-Developers/dp/1491941197

	Level IV Go Langauge Reference
		
		https://go.dev/
		Read Source Code Of Go Modules

