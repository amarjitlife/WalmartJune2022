
package main

import (
	"fmt"
	"math"
)

//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func division(dividend, divisor int ) ( int, int ) {
	if divisor != 0 {
		quotient := dividend / divisor
		remainder := dividend % divisor
		return quotient, remainder
	} else {
		fmt.Println("Error: Division By Zero!")
	}
	return 0, 0
}
											// Labeled Tuple
func divisionAgain(dividend, divisor int ) ( quotient int, remainder int ) {
	
	if divisor != 0 {
		quotient := dividend / divisor
		remainder := dividend % divisor
		return quotient, remainder
	} else {
		fmt.Println("Error: Division By Zero!")
	}
	return 0, 0
}

var xx int = 100

func playWithDivision() {
	q, r := division( 10, 3 )

	fmt.Printf("\nquotient: %d remainder: %d", q, r)

	qq, rr := divisionAgain( 10, 3 )
	fmt.Printf("\nquotient: %d remainder: %d", qq, rr)

	fmt.Println( xx )
}

//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

// Closures In Go
func playWithClosures() { // Enclosing Context
	var x, y = 30, 10

	// Closure/Lambda Expression
	add := func( x, y int ) int { return x + y }
	sub := func( x, y int ) int { return x - y }

	result := add( x, y )
	fmt.Println("\nResult :", result )

	result = sub( x, y )
	fmt.Println("\nResult :", result )

	start := 0

	incrementBy7 := func() int { // Enclosed Context
		// Enclosed Context Captures Enclosing Context
		//		Hence start Varible Is Accessible Inside
		start = start + 7
		return start
	}

	incrementBy10 := func() int { // Enclosed Context
		// Enclosed Context Captures Enclosing Context
		//		Hence start Varible Is Accessible Inside
		start = start + 10
		return start
	}

	result = incrementBy7()
	fmt.Println("incrementBy7 :", result )

	result = incrementBy7()
	fmt.Println("incrementBy7 :", result )

	result = incrementBy7()
	fmt.Println("incrementBy7 :", result )

	result = incrementBy7()
	fmt.Println("incrementBy7 :", result )

	result = incrementBy10()
	fmt.Println("incrementBy10 :", result )

	result = incrementBy10()
	fmt.Println("incrementBy10 :", result )
}


//___________________________________________________________________

// Higher Order Functions
//		Functions Which Takes Function As Arguments And/Or
//		Returns Functions

func calculator(x, y int, operation func(int, int) int ) int {
	// operation Stores Function/Closure
	//		Invoking Closure Passed In operation
	return operation(x, y)
}

//	Type Func  (int, int)  int

func div( x, y int ) int {	return x / y }

//	Type Func  (int, int, int )  int
func sum3( x, y, z int ) int { return x + y + z }

// func sum( x, y, z int ) int { return x + y + z }
// func sum( x, y int ) int { return x + y  }

func playWithFunctionsAndClosures1() {
	var x, y = 30, 10

	// Closure/Lambda Expression
	add := func( x, y int ) int { return x + y }
	sub := func( x, y int ) int { return x - y }
	mul := func( x, y int ) int { return x * y }

	// result := add( x, y )
	//			Configuring calculator Functions 
	result := calculator( x, y, add ) 
	fmt.Println("Result :", result )

	// result = sub( x, y )
	//			Configuring calculator Functions 
	result = calculator( x, y, sub )
	fmt.Println("Result :", result )

	//			Configuring calculator Functions 
	result = calculator( x, y, mul )
	fmt.Println("Result :", result )

	result = calculator( x, y, div )
	fmt.Println("Result :", result )

	// What Is The Data Type Of something???
	//		Type Func  (int, int)  int
	var something = div 
	result = something( 22, 11 )
	fmt.Println("Result :", result )

	// Compiler Error " cannot use sum3 (value of type func(x int, y int, z int) int) 
	//		as type func(x int, y int) int in assignment
	// something = sum3
	// result = something( 22, 11 , 100 )
	// fmt.Println("Result :", result )
}


//___________________________________________________________________

// Higher Order Functions
//		Functions Which Takes Function As Arguments And/Or
//		Returns Functions

// It Takes 0 Arguments
//		Return A Function Of Function Type
//			Which Takes float64 Type Argument And Return Value Of float64 Type

func Sphere() func(radius float64) float64 {

	volumeFunction := func( radius float64 ) float64 {
		volume := 4 / 3 * math.Pi * radius * radius * radius
		return volume
	}

	return volumeFunction
}

func playWithFunctionsAndClosures2() {
// 	sphereVolume Stores A Function Returned By Sphere()
//			A Function Which Takes float64 Type Argument And Return Value Of float64 Type
	sphereVolume := Sphere()

//									  Invoking Function
	fmt.Println("Volume Of Sphere: ", sphereVolume( 5 ) )
	fmt.Println("Volume Of Sphere: ", sphereVolume( 10 ) )
}

//___________________________________________________________________

// HOME WORK
// 		Simulate Following Scenario Using Higher Order Functions

// type Food struct 	{ }
// type Recipe struct 	{ }
// type Cook struct 	{ } 
// type Request struct { }
// type Desire struct  { }

// func cooking(cook Cook, recipe Recipe, request Request) Food {
// 	// Cook Knows These Recipes
// 	pasta 	:== func() string { fmt.Println("Cooking Pasta...") }
// 	biryani :== func() string { fmt.Println("Cooking Biryani...") }

// 	// askLadyOfHouse
// 		request, recipe = ladyOfHouse()
	
// 	// askManOfHouse
// 		request, recipe = manOfHouse()

// 	// askKidsOfHouse
// 		request, recipe = ladyOfHouse()

// 	if request == pasta {
// 		food := pasta()
// 		return food
// 	}

// 	if request == biryani {
// 		food := biryani()
// 		return food
// 	}

// 	if (request == somethingElse ) {
// 		food := recipe()
// 		return  food
// 	}

// }

// func ladyOfHouse( desire Desire ) ( Request, func() Recipe) {
// 	muttonBiryani := func() string { fmt.Println("Cooking Muttong Briyani...") }

// 	return request, muttonBiryani
// }

// func manOfHouse( desire Desire ) ( Request, func() Recipe) {
// 	chilliPaneer := func() string { fmt.Println("Cooking Chilli Paneer...") }

// 	return request, chilliPaneer
// }


//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func firstFunction() {
	fmt.Println("First Function Called..")
}

func secondFunction() {
	fmt.Println("Second Function Called..")
}

func c() (i int) {
    defer func() { i++ }()
    return 1
}

func playWithFunctions() {
	// firstFunction()
		// Function : playWithFunctions
		// First Function Called..
		// Second Function Called..

	// defer Keyword Delays Exectution Of Statement
	//		Till Exit Of This Function
	defer firstFunction()
		// Function : playWithFunctions
		// Second Function Called..
		// First Function Called..

	secondFunction()
	// defer Statement Will Be Called Just Before Exit From This Function

// In this example, a deferred function increments the return value i 
// after the surrounding function returns. Thus, this function returns 2:
	fmt.Println("c Function: ", c() )
}
// The behavior of defer statements is straightforward and predictable. 
// There are three simple rules:
// 	1. A deferred function’s arguments are evaluated when the defer statement is evaluated.
//  2. Deferred function calls are executed in Last In First Out order 
		// after the surrounding function returns.
// 3. Deferred functions may read and assign to the returning function’s named return values.

//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!


func main() {
	fmt.Println("\nFunction : playWithDivision")
	playWithDivision()

	fmt.Println("\nFunction : playWithClosures")
	playWithClosures()

	fmt.Println("\nFunction : playWithFunctionsAndClosures1")
	playWithFunctionsAndClosures1()

	fmt.Println("\nFunction : playWithFunctionsAndClosures2")
	playWithFunctionsAndClosures2()

	fmt.Println("\nFunction : playWithFunctions")
	playWithFunctions()

	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")	
	// fmt.Println("\nFunction : ")	
	// fmt.Println("\nFunction : ")	
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
}

