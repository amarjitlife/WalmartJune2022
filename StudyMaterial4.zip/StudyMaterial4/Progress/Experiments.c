#include <stdio.h> 
#include <stdbool.h>
#include <limits.h>

void playWithDataTypes() {
	bool c, python, java;

	// Best Practice
	//		Always Initialise Variables/Constants To Legal Value
	int i;
	printf("\n%d %d %d %d\n", c, python, java, i);
}

void playWithIfElse() {
	int x = -10;
	if( x ) { printf("If Block"); }
	else  	{ printf("Else Block"); }
}

// Why C/C++ Designers Selected Following Desing
//		char Doesn;t Have Default Range, It's Platform/Hardware Dependent
void playWithCharType() {
	char ch = 0; // [-128 to 127 ]
	int i; // Default Signed [ -32768, 32767 ]

	// Output Of Following Loop Is Indeterminate
	for( ; ch < 255 ; ch++ ) {
		printf("Ch value: %c %d\n", ch, ch);
	}
}

void playWithDataTypesAgain() {
	int i = 100;
	long l = 900;
	long ll = l + i;
	printf(" \nResult : %ld", ll);
}

//___________________________________________________

int sum(int x, int y) {
	return x + y;
}

void playWithSum() {
	int x = 2147483647;
	int y = 2;
	int z = x + y;
	printf( "\nResult : %d\n", z );

	int xx = -2147483647;
	int yy = -2;
	int zz = xx + yy;
	printf( "Result : %d\n", zz );
}

//___________________________________________________

// Following Code Is Platform Independent!
// Type Safe Code
//	Repspecting Type Definition Like God!
signed int summation(signed int si_a, signed int si_b) {
	  signed int sum = 0;
	  if (((si_b > 0) && (si_a > (INT_MAX - si_b))) ||
	      ((si_b < 0) && (si_a < (INT_MIN - si_b)))) {
		printf("\nCan't Calculate Sum For Given Values");
	  } else {
		sum = si_a + si_b;
		return sum;
	  }
}

//___________________________________________________

// Design Principle C/C++
//	You Should Not Pay For It! If You Are Not Using It!
void playWithStrings() {
	// There Is No String Type In C
	// In C
	//	String Follows ASCII Coding
	char greeting[] = "Good Morning!";	
	char *greetingAgain = "Good Morning!";

	printf("\nGreeting : %s", greeting );
	for ( int i = 0 ;  greeting[i] != '\0' ; i++ ) {
		printf("\nGreeting Character: %c", greeting[i] );
	}
}

//___________________________________________________

void playWithArrays() {
	int a[3];
	for ( int i = 0 ; i < 3 ; i++ ) {
		printf("At index: %d value: %d\n", i, a[i] );
	}

	printf("At index: %d value: %d\n", 3, a[3] );	// CTE // RTE 
}

//___________________________________________________

void playWithPointers() {
	int a = 20;
	int *ptr = &a ; 
	printf("\na Value: %d \na Address: %p\n Value At Address: %d\n", a, ptr, *ptr);
}

//___________________________________________________

void doChange0(int *ptr) {
        int b = 30;
        *ptr = 999;
	    ptr = &b;
        b = b + 50;
}

void doChange1(int **ptr) {
        int b = 30;
        **ptr = 999;
        *ptr = &b;
        b = b + 50;
}

int playWithPointersAgain() {
        int a = 20;
        int *ptr = &a;
        //      Passing The Reference OF

        doChange0( ptr );
        doChange1( &ptr );
        printf("\n Output: %d\n", *ptr);
        printf("\n Output: %d\n", a);
}

//___________________________________________________

void doChangeArray0(int a[], int len) {
	for ( int i = 0 ; i < len ; i++ ) {
		a[i] = 888;
	}
}

void doChangeArray1(int *bptr, int len) {
	for ( int i = 0 ; i < len ; i++ ) {
		bptr[i] = 999;
	}
}

void playWithArraysAgain() {
	int a[5] = { 10, 20, 30, 40, 50 };
	int len = 5;
	
	printf("\nArray Before doChangeArray");
	for ( int i = 0 ; i < len ; i++ ) { printf("\nAt index: %d value: %d", i, a[i]); }

	doChangeArray0( a, len );
	printf("\nArray After doChangeArray");
	for ( int i = 0 ; i < len ; i++ ) { printf("\nAt index: %d value: %d", i, a[i]); }

	int b[5] = { 10, 20, 30, 40, 50 };
	printf("\nArray Before doChangeArray");
	for ( int i = 0 ; i < len ; i++ ) { printf("\nAt index: %d value: %d", i, b[i]); }
	doChangeArray1( b, len );
	printf("\nArray After doChangeArray");
	for ( int i = 0 ; i < len ; i++ ) { printf("\nAt index: %d value: %d", i, b[i]); }
}

//___________________________________________________
int main() {
	printf("\nFunction : playWithDataTypes");
	playWithDataTypes();

	printf("\nFunction : playWithIfElse");
	playWithIfElse();

	printf("\nFunction : playWithCharType");
	playWithCharType();

	printf("\nFunction : playWithDataTypesAgain");
	playWithDataTypesAgain();

	printf("\nFunction : playWithSum");
	playWithSum();

	printf("\nFunction : playWithStrings");
	playWithStrings();

	printf("\n\nFunction : playWithArrays\n");
	playWithArrays();

	printf("\nFunction : playWithPointers");
	playWithPointers();

	printf("\nFunction : playWithPointersAgain");
	playWithPointersAgain();

	printf("\nFunction : playWithArraysAgain");
	playWithArraysAgain();
}
