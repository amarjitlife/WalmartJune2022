package main

import (
    "fmt"
    "time"
)

func main() { // Go Routine1 : Main Routine
    // Routine 1
    // Buffered Channel
    //      Having Finite Size
    messages := make(chan string, 3)

    go func() { 
        // Routine 2
        // Writing To messages Channel
        messages <- "Ping" 
        messages <- "Pong" 
        messages <- "Ting"
        messages <- "Tong" 
    
        fmt.Println("Go Routine 2 : Done")
    }()

    // Routine 1
    // Reading From Channel
    msg := <- messages
    fmt.Println(msg)

    // msg = <- messages
    // fmt.Println(msg)

    // msg = <- messages
    // fmt.Println(msg)

    // msg = <- messages
    // fmt.Println(msg)
    time.Sleep(time.Second * 10 )
}

