
package main

import (
      "fmt"
      "os"
      // "strings"
      // "flag"
)

//________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, RAISE YOUR HANDS!!!

// Function Doesn't Take Any Argument and Doesn;t Return Anything

func helloWorld() { 
      // In Go Lang Strings Are Unicode String
      //    Unicode???
      fmt.Println("Hello World! \u1F496 \u2665 \U0001F3A8")
}

const boildingF = 212.0 // Constant Value , Global Value
 
// Function Take One Argument and Returns One Value 
func fToC( f float64 ) float64 { 
      return ( f -32 ) * 5 / 9  
}

func playWithConstantVariables() {
      // f And c Are Variables : Local To Function
      var f = boildingF 
      var c = ( f -32 ) * 5 / 9
      fmt.Printf("Boilding Point = %g Farenheith or %g Centigrade ", f, c)

      // Elegant Assignment Syntax
      const freezingF, boildingF = 32.0, 212.0  // Local To Function
                                                             // Invoking Function
                  // %g Is Placeholder, Where Printf Arguments Substitution Will Happen
                  //          In Left To Right
      fmt.Printf("\n%g Farenheith or %g Centigrade ", freezingF, fToC(freezingF))
      fmt.Printf("\n%g Farenheith or %g Centigrade ", boildingF, fToC(boildingF))
}

// Usign Imported Packages
func playWithStrings() {
      // var n = flag.Bool("n", false, "Omit Trailing NewLine...")
      // var sep = flag.String("s", " ", "seperator")
}

// Celisus, Fahrenheit Is Alias For Type float64
// Defining Domain Knowledge To Improve Code Readability

// Naming Conventions For Identifiers
//          Identifiers Follows Camel Cases With First Word In Small
//                These Are Local To Package
//          In Case Identifier's First Alphabet Is Capital 
//                These Are Exported From Package
//                i.e. Accessible Outside Package e.g. Printf Function In fmt Package 

type Celsius float64
type Fahrenheit float64 

func FToC( f Fahrenheit ) Celsius {  return Celsius( ( f - 32 ) * 5 / 9 )  }
func CToF( c Celsius ) Fahrenheit {  return Fahrenheit( c * 9/5 + 31 )    }

const (
      BoildingC         Celsius = 100.0 // Constant Value , Global Value      
      FreezingC         Celsius = 0
      AbsoluteZeroC     Celsius = -273.15
)

func playWithLocalScope() {
      {
            fmt.Printf("\n %g ", BoildingC+FreezingC )
            boildingF := CToF( BoildingC )
            fmt.Printf("\n %g ", boildingF - CToF( FreezingC ))
      }

      fmt.Printf("\n %g ", boildingF)
      // fmt.Printf("\n %g ", boildingF + FreezingC )
}

func playWithForLoop() {
      var s, sep string

      for i := 1; i < len(os.Args) ; i ++ {
            s += sep + os.Args[i]
            sep = " "
      }
      fmt.Println(s)
}


func main() {

      fmt.Println("\nFunction : helloWorld")
      helloWorld()

      fmt.Println("\nFunction : playWithConstantVariables")
      playWithConstantVariables()
        
      fmt.Println("\nFunction : playWithLocalScope")
      playWithLocalScope()

      fmt.Println("\nFunction : playWithForLoop")
      playWithForLoop()

      // fmt.Println("\nFunction : ")
      // fmt.Println("\nFunction : ")
      // fmt.Println("\nFunction : ")
      // fmt.Println("\nFunction : ")
      // fmt.Println("\nFunction : ")
      // fmt.Println("\nFunction : ")
      // fmt.Println("\nFunction : ")
      // fmt.Println("\nFunction : ")
      // fmt.Println("\nFunction : ")
      // fmt.Println("\nFunction : ")
      // fmt.Println("\nFunction : ")
      // fmt.Println("\nFunction : ")
      // fmt.Println("\nFunction : ")
      // fmt.Println("\nFunction : ")
      // fmt.Println("\nFunction : ")        
}
