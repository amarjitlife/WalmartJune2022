
package main 

import (
	"fmt"
	"time"
)

func doSomething(from string) {
	for i := 0 ; i < 3 ; i++ {
		fmt.Println(from, " : ", i )
		time.Sleep(time.Second * 2)	
	}
}

func playWithGoRoutines() { // Main Go Routine
	fmt.Println(time.Now().Format(time.RFC850))

	// doSomething("Direct")  // Blocking Functions
	go doSomething("Direct")  // Non-Blocking Functions

	//doSomething("Once More Called") // Blocking Functions
	go doSomething("Once More Called") // Non Blocking Functions

	// go doSomething("Go Routine")
	// func( message string ) { // Blocking Functions
	// 	fmt.Println( message )
	// 	time.Sleep(time.Second * 3 )
	// }("Here Goes One More Go Routine...")

	go func( message string ) { // Non Blocking Functions
		fmt.Println( message )
		time.Sleep(time.Second * 3 )
	}("Here Goes One More Go Routine...")

	time.Sleep(time.Second * 10)
	fmt.Println("Done")
	fmt.Println(time.Now().Format(time.RFC850))
}

func main() {
	fmt.Println("\nFunction : playWithGoRoutines")
	playWithGoRoutines()
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")	
	// fmt.Println("\nFunction : ")	
	// fmt.Println("\nFunction : ")	
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
}
