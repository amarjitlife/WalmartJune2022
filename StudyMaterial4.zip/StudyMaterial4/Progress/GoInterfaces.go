
package main

import (
	"fmt"
	"math"
)

//___________________________________________________________________

// Duck Typing
// duck test—
// 		"If it walks like a duck and 
//		it quacks like a duck, 
//		then it must be a duck


// Interfaces Tells
// 		What It Will Do?
//		Not How, When, Where, Which Way etc...
type Geometry interface {
	area() float64
	perimeter() float64
	// origin() (float64, float64 )
}

type Rectangle struct {
	width, height float64
}

type Circle struct {
	radius float64
}

// Methods Binded With Rectangle Type
func (r Rectangle) area() float64 {
	return r.width * r.height
}

func (r Rectangle) perimeter() float64 {
	return 2 * (r.width + r.height)
}

func (r Rectangle) origin() (float64, float64) {
	return 0.0, 0.0
}

// Methods Binded With Circle Type
func (c Circle) area() float64 {
	return math.Pi * c.radius * c.radius
}

func (c Circle) perimeter() float64 {
	return 2 * math.Pi * c.radius
}

func (c Circle) origin() (float64, float64) {
	return 0.0, 0.0
}

func measureGeometry( g Geometry ) {
	fmt.Println( g )
	fmt.Println( g.area() )
	fmt.Println( g.perimeter() )

	// fmt.Println( g.origin() )
}

func playWihGeometry() {
	r := Rectangle{ width: 10, height: 20 }
	c := Circle{ radius : 10 }

	fmt.Printf("\nRectangle Area: %f Perimeter: %f", r.area(), r.perimeter() )
	fmt.Printf("\nCirclle Area: %f Perimeter: %f", c.area(), c.perimeter() )

	fmt.Println("\nMagic Happens Here Onwards...")
	measureGeometry( r )
	measureGeometry( c )
}

//___________________________________________________________________

// package fmt

// func Fprintf(w io.Writer, format string, args ...interface{}) (int, error)

// func Printf(format string, args ...interface{}) (int, error) {
// 	 return Fprintf(os.Stdout, format, args...)
// }

// func Sprintf(format string, args ...interface{}) string {
// 	var buf bytes.Buffer
// 	Fprintf(&buf, format, args...)
// 	return buf.String()
// }  

//___________________________________________________________________

// //___________________________________


// package io

// type Writer interface {
// 	// Write writes len(p) bytes from p to the underlying data stream.
// 	// It returns the number of bytes written from p (0 <= n <= len(p))
// 	// and any error encountered that caused the write to stop early.
// 	// Write must return a non-nil error if it returns n < len(p).
// 	// Write must not modify the slice data, even temporarily.
// 	//
// 	// Implementations must not retain p.
// 	Write(p []byte) (n int, err error)
// }

//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!


func main() {
	fmt.Println("\nFunction : playWihGeometry")
	playWihGeometry()

	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")	
	// fmt.Println("\nFunction : ")	
	// fmt.Println("\nFunction : ")	
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
}


