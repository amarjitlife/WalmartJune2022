package main

import "fmt"

func main() { // Go Routine1 : Main Routine
    // Routine 1
    // Unbuffered Channel
    messages := make(chan string)

    go func() { 
        // Routine 2
        // Writing To messages Channel
        messages <- "Ping" 
        messages <- "Pong" 
        messages <- "Ting"
        messages <- "Tong" 

    }()

    // Routine 1
    // Reading From Channel
    msg := <- messages
    fmt.Println(msg)

    msg = <- messages
    fmt.Println(msg)

    msg = <- messages
    fmt.Println(msg)

    msg = <- messages
    fmt.Println(msg)
}

