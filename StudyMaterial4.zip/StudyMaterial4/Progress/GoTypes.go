
package main

import (
	"fmt"
	"math"
	"strings"
	"bytes"
	"strconv"
	// "cmplx"
)

//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

// Surface Plot Of Function Sin( R ) / R

const (
	// Tuple Assignment
	width, height = 600, 320 		// Canvas Size In Pixels
	cells = 100 			 		// Number Of Grid Cells
	xyrange = 30.0 					// Axis Ranges ( -xyrange..+xyrange)
	xyscale = width / 2 / xyrange 	// Pixles per x or y unit
	zscale = height * 0.4  			// Pixles per z unit
	angle = math.Pi / 6  			// angle of x, y axes ( = 30 Degree )
)

var sin30, cos30 = math.Sin(angle), math.Cos(angle)

// Function Takes Two int Type Arguments
//		Returns Tuple Of Two Values Of Type float64
//		Tuple Is Ordered Set

func corner(i, j int) ( float64, float64 ) {
	// Here x And y Will Be Of float64 Type
	//		1. Type Is Inferred From RHS Expression
	//		2. Inferred Type Is Binded With LHS
	x := xyrange * ( float64( i )  / cells - 0.5 )
	y := xyrange * ( float64( j )  / cells - 0.5 )

	// Here z Will Be Of float64 Type
	//		1. Type Is Inferred From RHS Expression
	//		2. Inferred Type Is Binded With LHS
	z := f(x, y)

	// Here sx And sy Will Be Of float64 Type
	//		1. Type Is Inferred From RHS Expression
	//		2. Inferred Type Is Binded With LHS
	sx := width/2 + ( x - y ) * cos30 * xyscale
	sy := height/2 + ( x + y) * sin30 * xyscale - z* zscale 

	return sx, sy // Returning Tuple Of Two Values
}

// Function Takes Two float64 Type Arguments
//		Returns One Value Of Type float64
//		Following Both Lines Are Same
// func f(x float64, y float64 ) float64 {
func f(x, y float64 ) float64 {
	r := math.Hypot(x, y)
	return math.Sin( r ) / r
}

func playWithCanvas() {
	fmt.Printf("<svg xmlns='http://www.w3.org/2000/svg' "+
	"style='stroke: grey; fill: white; stroke-width: 0.7' "+
	"width='%d' height='%d'>", width, height)

	for i := 0 ; i < cells ; i++ {
		for j := 0 ; j < cells ; j++ {

			ax, ay := corner( i + 1 , j )
			bx, by := corner( i , j )
			cx, cy := corner( i , j + 1 )
			dx, dy := corner( i + 1 , j + 1 )

			fmt.Printf("<polygon points='%g,%g %g,%g %g,%g %g,%g'/>\n",
				ax, ay, bx, by, cx, cy, dx, dy)

		}
	}

	fmt.Println("</svg>")
}

//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func playWithComplexTypes() {
	var x complex128 = complex(1, 2) 	// 1 + 2i
	var y complex128 = complex(3, 4) 	// 3 + 4i
	fmt.Println( x )
	fmt.Println( y )
	fmt.Println( x + y  )
	fmt.Println( x * y  )
	fmt.Println( real( x ) )  
	fmt.Println( imag( x ) )  

	fmt.Println( 1i * 1i )  

	xx := 1 + 2i
	yy := 3 + 4i
	fmt.Println( xx )
	fmt.Println( yy )
	fmt.Println( xx + yy  )
	fmt.Println( xx * yy  )
	fmt.Println( real( xx ) )  
	fmt.Println( imag( xx ) )  
	// fmt.Println( cmplx.Sqrt( -1 ) )
}

//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

// One More Go Inbuilt Type: string Type
func basename( s string ) string {
	for i := len(s) - 1 ; i >= 0 ; i-- {
		if s[i] == '/' {

			s = s [ i + 1 : ] // Slicing
			break 
		}
	}

	for i := len(s) - 1 ; i >= 0 ; i-- {
		if s[i] == '.' {
			s = s [ : i ] // Slicing
			break 
		}
	}

	return s
}

// Using strings Package Functions
func basenameAgain( s string ) string {
	slash := strings.LastIndex( s, "/" )
	s = s[ slash + 1 : ]

	if dot := strings.LastIndex( s, "." ) ; dot >= 0 {
		s = s[ : dot ]
	}

	return s
}

func playWithBaseName() {
	fmt.Println( basename( "/media/WorkArea/Trainings/WalmartLabs/GoBatch2/Progress" ) )
	fmt.Println( basename( "/media/WorkArea/Trainings/WalmartLabs/GoBatch2/Progress/GoFoundation.go" ) )

	fmt.Println( basenameAgain( "/media/WorkArea/Trainings/WalmartLabs/GoBatch2/Progress" ) )
	fmt.Println( basenameAgain( "/media/WorkArea/Trainings/WalmartLabs/GoBatch2/Progress/GoFoundation.go" ) )

}

//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func playWithStringType() {
	s := "Hello, World!"

	fmt.Println( s )
	fmt.Println( "String Length : ", len( s ) )

	// 한 Can Be Represented With Unicode Point \uD55C"
	s1 := "Hello, World!\uD55C"
	fmt.Println( s1 )
	fmt.Println( "String Length : ", len( s1 ) )

	// 한 Can Be Represented With Unicode Point \u1112\u1161\u11AB"
	// "\u1112\u1161\u11AB"  // ᄒ, ᅡ, ᆫ	
	s2 := "Hello, World!\u1112\u1161\u11AB"
	fmt.Println( s2 )
	fmt.Println( "String Length : ", len( s2 ) )
	fmt.Println( "\u1112")
	fmt.Println( "\u1161")
	fmt.Println( "\u11AB")

	fmt.Println( s[0], s[7] )
	fmt.Println( s[ 0 : 5 ] )
	fmt.Println( s[ : 5 ] )
	fmt.Println( s[ 7 :  ] )
	fmt.Println( s[  :  ] )

	fmt.Println( "Goodbye "+ s[ 5 :  ] )

	ss := "Left Foot"
	tt := ss
	fmt.Println( tt )
	ss += ", and Right Foot"
	fmt.Println( ss )

	// s[0] = 'L' // Compile Time Error: cannot assign to s[0] (value of type byte)
}

//___________________________________________________________________

// import (
//     "fmt"
//     s "strings"
// )

// var p = fmt.Println

func playWithStringsFunctions() {

    fmt.Println("Contains:  ", strings.Contains("test", "es"))
    fmt.Println("Count:     ", strings.Count("test", "t"))
    fmt.Println("HasPrefix: ", strings.HasPrefix("test", "te"))
    fmt.Println("HasSuffix: ", strings.HasSuffix("test", "st"))
    fmt.Println("Index:     ", strings.Index("test", "e"))
    fmt.Println("Join:      ", strings.Join([]string{"a", "b"}, "-"))
    fmt.Println("Repeat:    ", strings.Repeat("a", 5))
    fmt.Println("Replace:   ", strings.Replace("foo", "o", "0", -1))
    fmt.Println("Replace:   ", strings.Replace("foo", "o", "0", 1))
    fmt.Println("Split:     ", strings.Split("a-b-c-d-e", "-"))
    fmt.Println("ToLower:   ", strings.ToLower("TEST"))
    fmt.Println("ToUpper:   ", strings.ToUpper("test"))
}

//___________________________________________________________________

// In C Language
	// There Is No String Type In C
	// String Value Denoted By ""
	// String Is Sequence Of ASCII Characters Stored In char Type Array
	// In C
	//		String Follows ASCII Coding
	//		String Ends With '\0' Null ASCII Character In Memory


// In Go Language
	// A string is an immutable sequence of bytes. 
	// Strings may contain arbitrary data, including bytes with value 0, 
	// but usually they contain human-readable text. 

	// Text strings are conventionally interpreted as UTF-8-encoded sequences 
	// of Unicode code points (runes)
	// It Stores Unicode Characters

	// Internal Structure Of string Type In Go Langauge

		// type _string struct {
		// 		elements *byte // underlying bytes
		// 		len      int   // number of bytes
		// }

// The built-in len function returns the number of bytes (not runes) in a string, 
// and the index operation s[i] retrieves the i-th byte of string s, where 0 ≤ i < len(s).


// The i-th byte of a string is not necessarily the i-th character of a string, because the UTF-8 encoding of a non-ASCII code point requires two or more bytes.

//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func insertCommas( s string ) string {
	n := len( s )

	if n <= 3 { return s }
	return insertCommas( s[ : n - 3] ) + "," + s[ n -3 : ]
}

func playWithInsertCommas() {
	fmt.Println( insertCommas( "12345678" ) )
	fmt.Println( insertCommas( "999" ) )
	fmt.Println( insertCommas( "6789999" ) )
	fmt.Println( insertCommas( "89389438493849384398439483" ) )
	fmt.Println( insertCommas( "123456788888888888" ) )
}

//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func intsToString( values []int ) string {
	var buffer bytes.Buffer

	buffer.WriteByte( '[' )

	for index, value := range values {
		fmt.Printf( "\nAt index: %d value: %v", index, value )

		if index > 0 {
			buffer.WriteString( ", " )
		}
		fmt.Fprintf( &buffer, "%d", value )
	} 
	buffer.WriteByte( ']' )

	return buffer.String()
}

func playWithIntToString() {
	fmt.Println( "\nString : ", intsToString( []int{ 10, 20, 30 } ) ) 
	
	fmt.Println( "\nString : ", 
		intsToString( []int{ 10, 20, 30, 99, 100, 101, 8000 } ) ) 
	
	fmt.Println( "\nString : ", 
		intsToString( []int{ 1000, 2000, 3000, 9000, 7000, 6000, 8000 } ) ) 
}


//___________________________________________________________________


func playWitStringUnicode() {
	const something = `⌘`

	fmt.Printf("Plain String: ")
	fmt.Printf("%s", something )
	fmt.Println()

	fmt.Printf("Quoted String: ")
	fmt.Printf("%q", something )
	fmt.Println()


	fmt.Printf("Hex Bytes: ")
	for i := 0 ; i < len( something ) ; i++ {
		fmt.Printf(" %x ", something[i] )
	}

	fmt.Println()	

	somethingAgain := "Hello, 한瘔"
	fmt.Println( somethingAgain )
	fmt.Println( len( somethingAgain ) )
	fmt.Printf("Hex Bytes: ")
	for i := 0 ; i < len( somethingAgain ) ; i++ {
		fmt.Printf(" %x ", somethingAgain[i] )
	}

	fmt.Println()	

	for index, character := range somethingAgain {
		fmt.Printf("\n%d\t %q \t %x", index, character, character)
	}

	characterCount := 0
	for _, _ = range somethingAgain {
		characterCount++
	}

	fmt.Println("\nUnicode Character Count : ", characterCount	)	

	characterCount = 0
	for range somethingAgain {
		characterCount++
	}

	fmt.Println("\nUnicode Character Count : ", characterCount	)

	x := 123

	// y Is string Type
	y := fmt.Sprintf( "%d", x )
	fmt.Println( y )

	fmt.Println( strconv.Itoa( x ) )
	fmt.Println( strconv.Atoi( "8970" ) )
}


//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

const (
	a = 1 
	b
	c = 2
	d
)

const (
	c0 = iota  	// c0 = 0
	c1 = iota 	// c1 = 1
	c2 = iota 	// c2 = 2
)

// const (
// 	aa = 1
// 	bb = 2
// 	cc = 4
// 	xx = 3
// 	dd = 16
// )

const (
	aa = 1 << iota 		// aa = 1  	( iota = 0 )  1 << 0  = 2^0
	bb = 1 << iota 		// bb = 2 	( iota = 1 )  1 << 1  = 2^1
	cc = 1 << iota 		// cc = 4 	( iota = 2 )  1 << 2  = 2^2
	xx = 3 				// 	 		( iota = 3 )  Unused iota Value
	dd = 1 << iota 		// dd = 8 	( iota = 4 )  1 << 4  = 2^4
)

const (
	u 			= iota * 42
	v float64 	= iota * 42
	w 			= iota * 42
)

const x = iota
const y = iota 

type Weekday int

// Following Two const Expressions Are Same

const (
	Sunday Weekday = iota
	Monday 
	Tuesday
	Wednesday
	Thursday
	Friday
	Saturday
)

// const (
// 	Sunday Weekday 	= iota
// 	Monday 			= iota 
// 	Tuesday			= iota
// 	Wednesday 		= iota
// 	Thursday		= iota
// 	Friday 			= iota
// 	Saturday 		= iota
// )

const (
    _ = 1 << (10 * iota)  	// 10 Raised To Power 0
    KiB // 1024  		 	// 10 Raised To Power 1 i.e. 2^10
    MiB // 1048576
    GiB // 1073741824
    TiB // 1099511627776
    PiB // 1125899906842624
    EiB // 1152921504606846976
    ZiB // 1180591620717411303424
    YiB // 1208925819614629174706176
)

func playWithConstantsAgain() {
	fmt.Println("a, b, c, d")	
	fmt.Println(a, b, c, d)

	fmt.Println("c0, c1, c2")
	fmt.Println(c0, c1, c2)

	fmt.Println("aa, bb, cc, dd")	
	fmt.Println(aa, bb, cc, dd)	
}


//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func main() {
	// playWithCanvas()

	fmt.Println("\nFunction : playWithComplexTypes")
	playWithComplexTypes()

	fmt.Println("\nFunction : playWithBaseName")
	playWithBaseName()

	fmt.Println("\nFunction : playWithStringType")
	playWithStringType()

	fmt.Println("\nFunction : playWithStringsFunctions")
	playWithStringsFunctions()

	fmt.Println("\nFunction : playWithInsertCommas")
	playWithInsertCommas()

	fmt.Println("\nFunction : playWithIntToString")
	playWithIntToString()

	fmt.Println("\nFunction : playWitStringUnicode")
	playWitStringUnicode()

	fmt.Println("\nFunction : playWithConstantsAgain")
	playWithConstantsAgain()

	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")	
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")	
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")	
}

