
package composition

// __________________________________________________________________
// DESIGN I 

open class SpidermanOld {
	open fun fly() 		{ println(" Fly Like Spiderman! ") }
	open fun saveWorld() { println(" Saveworld Like Spiderman! ") }
}

// Using Inheritance
class HumanOld : SpidermanOld() {
	override fun fly() 			{ super.fly() }
	override fun saveWorld() 	{ super.saveWorld() }
}

// __________________________________________________________________
// DESIGN II 

// Design Towards Interfaces Rather Than Concrete Classes
//		Interfaces Promotes Behaviour First Design
//		It Becomes Protocol Oriented Design

// Interface
interface Superpower {
	fun fly()
	fun saveWorld()
}

// Concrete Class
class Spiderman : Superpower {
	// Behaviour
	override fun fly() 		{ println(" Fly Like Spiderman! ") }
	override fun saveWorld() { println(" Saveworld Like Spiderman! ") }
}

// Concrete Class
class Superman: Superpower {
	override fun fly() 		{ println(" Fly Like Superman! ") }
	override fun saveWorld() { println(" Saveworld Like Superman! ") }
}

class Heman : Superpower {
	override fun fly() 		{ println(" Fly Like Heman! ") }
	override fun saveWorld() { println(" Saveworld Like Heman! ") }
}

class HanumanJi : Superpower {
	override fun fly() 		{ println(" Fly Like Jai Sriram!! ") }
	override fun saveWorld() { println(" Saveworld Lie Jai Sriram! ") }
}

// Using Composition
// 		Human Is Polymorphic
class Human {
	// Human Was Tigthly Couple With Spiderman/Superman/Heman
	// var power : Spiderman = Spiderman()
	// var power : Superman = Superman()
	// var power : Heman = Heman()

	// Human Is Loosely Couple
	//		Because It Depends On Only One Thing That's Interface
	var power : Superpower? = null 
	fun fly() 			{ power?.fly() }
	fun saveWorld() 	{ power?.saveWorld() }
}

fun main() {
	var humanOld = HumanOld()
	humanOld.fly()
	humanOld.saveWorld()

	println("Magic Happens Here Onwards....")
	var human = Human()
	human.power = Spiderman() // Configuring Human
	human.fly()
	human.saveWorld()

	human.power = Superman() // Configuring Human
	human.fly()
	human.saveWorld()

	human.power = Heman() // Configuring Human
	human.fly()
	human.saveWorld()

	human.power = HanumanJi() // Configuring Human
	human.fly()
	human.saveWorld()
}

