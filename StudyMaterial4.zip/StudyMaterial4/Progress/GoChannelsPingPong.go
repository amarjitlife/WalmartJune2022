

package main

import "fmt"

//	pings Is Write Only Channel
func ping(pings chan<- string, msg string) {
    pings <- msg
}

//	pings Is Read Only Channel
//	pings Is Write Only Channel
func pong(pings <-chan string, pongs chan<- string) {
    msg := <- pings
    // pings <- "Hello"
    pongs <- msg
}

func main() {
	// To Set Two Way Communication Using Channels
    pings := make(chan string, 1)
    pongs := make(chan string, 1)

    ping(pings, "passed message")
    pong(pings, pongs)

    fmt.Println(<-pongs)
}

