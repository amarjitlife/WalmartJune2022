
package main

import (
	"fmt"
	"os"
	"strconv"
	"strings"
	"bufio"
	"unicode/utf8"
	"unicode"
	"io"
)


//___________________________________________________________________


func playWithDefaultInitialValues() {
	var a int
	var i8 int8
	var ui8 uint8

	var f1 float32
	var f2 float64

	var s string

	var c1 complex64 
	var c2 complex128

	var b bool

	fmt.Printf("%d %d %d\n", a, i8, ui8)
	fmt.Printf("%f %f\n", f1, f2)	
	fmt.Printf("%s \n", s)	
	fmt.Printf("%v %v", c1, c2)	
	fmt.Printf("%t \n", b)	
}

// Function : playWithDefaultInitialValues
// 0 0 0
// 0.000000 0.000000
 
// (0+0i) (0+0i)false 

//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func playWithArrays() {
	// Creating Array of 2 ints
	//		Index Starts From 0 Till len - 1 i.e. [0, len) i.e. [0, len - 1]
	//		All Elements Of Array Intialised To Zeros Of Type

	var a [3]int

	// List Of Tuples : (0, member0), (1, member1), (2, member2)...
	//		Tuple Getting Upacked To Two Identifiers index And value
	for index, value := range a {
		fmt.Printf("At index: %d value: %d\n", index, value)
	}

	fmt.Println( a[0] )
	fmt.Println( a[1] )
	fmt.Println( a[ len( a ) - 1 ] )

	// Compile Time Error : invalid argument: array index 3 out of bounds [0:3]
	// fmt.Println( a[ len( a ) ] ) 
	// _ Means Identifier Which You Wnat To Ignore
	for _, value := range a {
		fmt.Printf("value: %d\n", value)
	}

	var q [5]int = [5]int{ 10, 20, 30, 40, 50 }
	var r [5]int = [5]int{ 10, 20, 30 }

	fmt.Println("Array Length : ", len(q) )
	for index, value := range q {
		fmt.Printf("At index: %d value: %d\n", index, value)
	}

	fmt.Println("Array Length : ", len(r) )
	for index, value := range r {
		fmt.Printf("At index: %d value: %d\n", index, value)
	}

	s := [...]int{ 10, 20, 100, 111 }
	fmt.Println("Array Length : ", len(s) )
	fmt.Printf( "Data Type : %T \n", s )

	for index, value := range s {
		fmt.Printf("At index: %d value: %d\n", index, value)
	}

	some := [3]int { 100, 200, 300 }
	fmt.Printf( "Data Type : %T \n", some )

	someAgain := [...]int{ 99 : - 1 }
	fmt.Println("Array Length : ", len( someAgain ) )
	fmt.Printf( "Data Type : %T \n", someAgain )

	for index, value := range someAgain {
		fmt.Printf("At index: %d value: %d\n", index, value)
	}

	aa := [2]int{ 10, 20 }
	bb := [...]int{ 10, 20 }
	cc := [2]int{ 10, 30 }

	fmt.Println( aa == bb, aa == cc, bb == cc )
	// true false false

	dd := [3]int{ 10, 30 }
	fmt.Println( dd )
	// Compilation Error: 
	// 	invalid operation: aa == dd (mismatched types [2]int and [3]int)
	// fmt.Println( aa == dd )
}

//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

type Flags uint

const ( // STATUS BITs ARE DEFINED AS FOLLOWS
    FlagUp Flags = 1 << iota // is up
	FlagBroadcast		 	 // supports broadcast access capability
	FlagLoopback             // is a loopback interface
	FlagPointToPoint         // belongs to a point-to-point link
	FlagMulticast            // supports multicast access capability
)

func IsUp(v Flags) bool     { return v & FlagUp == FlagUp } // & (bitwise AND)
func TurnDown(v *Flags)     { *v &^= FlagUp }   // &^ (AND NOT): This is a bit clear operator.
func SetBroadcast(v *Flags) { *v |= FlagBroadcast } // | (bitwise OR)
func IsCast(v Flags) bool   { return v & (FlagBroadcast | FlagMulticast) != 0 }

func playWithFlags() {
	var v Flags = FlagMulticast | FlagUp
	fmt.Printf("%b %t\n", v, IsUp(v)) // "10001 true"
	
	TurnDown( &v )
	fmt.Printf("%b %t\n", v, IsUp(v)) // "10000 false"
	
	SetBroadcast( &v )
	fmt.Printf("%b %t\n", v, IsUp(v))   // "10010 false"
	fmt.Printf("%b %t\n", v, IsCast(v)) // "10010 true"
}

//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

// In C By Default
//		Arrays Are Pass By Reference
// In Go By Default
//		Arrays Are Pass By Value
func changeArray0( a [5]int ) {
	for i, _ := range a {
		a[i] = 777
	}
	fmt.Println("Inside changeArray0: ", a )
}

//	Implementing Arrays Pass By Reference
// In Go - To Pass Array By Reference
//		Pass Reference/Address To Function Call Using & Operator
//		Function Arguments Must Be Address/Referemce Type	
func changeArray1( a *[5]int ) {
	for i, _ := range a {
		a[i] = 888
	}
	fmt.Println("Inside changeArray1: ", a )
}

// In Go Slices Are Pass By Reference
func changeArray2( slice []int ) {
	for i, _ := range slice {
		slice[i] = 999
	}
	fmt.Println("Inside changeArray2: ", slice )
}

func playWithChangeArrays() {
	var aa [5]int = [5]int{ 10, 20, 30, 40, 50 }

	fmt.Println("Before changeArray0: ", aa )
	changeArray0( aa )
	fmt.Println("After  changeArray0: ", aa )

	var bb [5]int = [5]int{ 10, 20, 30, 40, 50 }
	fmt.Println("Before changeArray1: ", bb )
	changeArray1( &bb )
	fmt.Println("After  changeArray1: ", bb )

	var cc [10]int = [10]int{ 10, 20, 30, 40, 50, 60, 70, 80, 90, 100 }
	fmt.Println("Before changeArray2: ", cc )
	// Slices Are Pass By Reference
	//		Passing Array Slice Of Full Array cc i.e. Index 0 to len - 1 
	changeArray2( cc[ : ] ) 
	fmt.Println("After  changeArray2: ", cc )

	cc = [10]int{ 10, 20, 30, 40, 50, 60, 70, 80, 90, 100 }
	changeArray2( cc[ : 4 ] ) 
	fmt.Println("After  changeArray2: ", cc )

	cc = [10]int{ 10, 20, 30, 40, 50, 60, 70, 80, 90, 100 }
	changeArray2( cc[ 6 :  ] ) 
	fmt.Println("After  changeArray2: ", cc )

	cc = [10]int{ 10, 20, 30, 40, 50, 60, 70, 80, 90, 100 }
	changeArray2( cc[ 3 : 7 ] ) 
	fmt.Println("After  changeArray2: ", cc )

}

//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func playWithSlices() {
	// Array Of Strings
	months := [...]string{ 0 : "", "Jan", "Feb", "Mar", "Apr", "May", 
						"Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" }
	
	fmt.Println("Months : ", months )

	// Creating Slices From Array months
	quater1 := months[ 1 : 4 ]
	quater2 := months[ 4 : 7 ]
	summer  := months[ 2 : 7 ]

	// summerAgain  := months[ 2 : 20 ]

	fmt.Println("Quater1 :", quater1)
	fmt.Println("Quater2 :", quater2)

	fmt.Println("Summer  :", summer)

	for _, s := range summer {
		for _, q := range quater2 {
			if s == q {
				fmt.Printf(" %s Appears In Both \n", s)
			}
		}
	}
}

//___________________________________________________________________


//_____________________________________________________________________________________
// 						
// 									GO SLICES CONCEPTS
//_____________________________________________________________________________________


// Slices represent variable-length sequences whose elements all have the same type. 
// 	A slice type is written []T, where the elements have type T; 
// 		it looks like an array type without a size.

// A slice is a lightweight data structure that gives access to a subsequence (or perhaps all)
// 	 of the elements of an array, which is known as the slice’s underlying array. 

// 	A slice has three components: a pointer, a length, and a capacity. 
// 		The pointer points to the first element of the array that is reachable through the slice, 
// 			which is not necessarily the array’s first element. 
// 		The length is the number of slice elements; it can’t exceed the capacity, 
// 			which is usually the number of elements between 
// 			the start of the slice and the end of the underlying array. 

// 		The built-in functions len and cap return those values.

// The slice operator s[ i : j ], where 0 ≤ i ≤ j ≤ cap(s), 
// 	Creates a new slice that refers to elements i through j-1 of the sequence s, 
// 	which may be an array variable, a pointer to an array, or another slice. 
// 	The resulting slice has j-i elements. 
// 	If i is omitted,it’s 0,and if j isomitted, it’s len(s). 

// 	Thus the slice months[1:13] refers to the whole range of valid months, 
// 	as does the slice months[1:]; the slice months[:] refers to the whole array.



//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func reverse( slice []int ) {
	for i, j := 0, len( slice ) -1  ;  i < j  ;  i, j = i + 1, j - 1 {
		slice[i], slice[j] = slice[j], slice[i]
	}
}

// In Go Slices Are Pass By Reference
// s
func slicesEqual(x, y []int ) bool {
	if len( x ) != len( y ) {
		return false 
	}

	for i := range x {
		if x[i] != y[i] {
			return false
		}
	}
	return true
}

func playWithArrayAndSlices() {
	// a Is An Array
	a := [...]int { 10, 20, 30, 40, 50, 60, 70, 80, 90 }
	
	fmt.Println( a )
	reverse( a [ : ] )
	fmt.Println( a )

	// s Is A Slice: Array Syntax Withoud Size Information
	s := []int { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 }
	
	fmt.Println( s )
	reverse ( s[ : 5 ] ) 
	fmt.Println( s )
	reverse ( s[ 5 :  ] ) 
	fmt.Println( s )

	changeArray2( s[ 3 : 6 ] )
	fmt.Println( s )

	slice1 := a[ 2 : 6 ]
	slice2 := a[ 2 : 6 ]
	slice3 := a[ 5 : 8 ]

	// invalid operation: slice1 == slice2 (slice can only be compared to nil)
	// fmt.Println( slice1 == slice2 )
	// fmt.Println( slice1 == slice3 )
	// fmt.Println( slice2 == slice3 )

	fmt.Println( slicesEqual( slice1, slice2 )  )
	fmt.Println( slicesEqual( slice1, slice2 )  )
	fmt.Println( slicesEqual( slice2, slice3 )  )
}

//___________________________________________________________________


func playWithSlicesFunctions() {

// The built-in function make creates a slice of a specified element type, length, and capacity.
// The capacity argument may be omitted, in which case the capacity equals the length.
// 		make([]T, len)
// 		make([]T, len, cap) // same as make([]T, cap)[:len]

	s := make( []string, 3 )	// Background Array
	fmt.Println( "Empty Slice : \n", s )
	fmt.Printf( "Empty Slice Type : %T\n", s )
	fmt.Printf( "Length: %d Capacity: %d", len( s ), cap( s ) )

	s[0] = "a"
	s[1] = "b"
	s[2] = "c"

	fmt.Println( "Slice : \n", s )
	fmt.Println( "Slice Element s[2] : \n", s[2] )

	s = append( s, "d" ) 			// Background Array Of Size 4 Allocated
	
	fmt.Println( "Slice : \n", s )
	s = append( s, "e", "f" )
	
	fmt.Println( "Slice : \n", s ) 	// Background Array Of Size 6 Allocated
	fmt.Printf( "Length: %d Capacity: %d", len( s ), cap( s ) )

	c := make( []string, len( s ) )
	c = s 	// Reference Assignnment

	fmt.Println("s Slice : ", s)
	fmt.Println("c Slice : ", c)
	// s Slice :  [a b c d e f]
	// c Slice :  [a b c d e f]

	s[0] = "Hello!"

	fmt.Println("s Slice : ", s)
	fmt.Println("c Slice : ", c)

	// s Slice :  [Hello! b c d e f]
	// c Slice :  [Hello! b c d e f]

	s[0] = "a"

	fmt.Println("s Slice : ", s)
	fmt.Println("c Slice : ", c)
	// s Slice :  [a b c d e f]
	// c Slice :  [a b c d e f]

	ss := make( []string, 0 )

	fmt.Println(">>> ss Slice: ",  ss )
	// fmt.Println(">>>>ss Slice Element ss[0]: ",  ss[0] )

	ss = append( ss, "AA", "BB", "CC", "DD", "EE", "FF")

	cc := make( []string, len( ss ) )

	fmt.Println("ss Slice: ",  ss )
	fmt.Println("cc Slice: ",  cc )

	copy( cc, ss )

	fmt.Println("ss Slice: ",  ss )
	fmt.Println("cc Slice: ",  cc )

	ss[0] = "Good Morning!!!"

	fmt.Println("ss Slice: ",  ss )
	fmt.Println("cc Slice: ",  cc )

	tt := []string{ "Ding", "Dong", "Ming", "Mong" }
	fmt.Println("tt Slice: ",  tt )
	fmt.Printf("tt Slice Type : %T",  tt )

}


//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func playWithReadingInputs() {

	input := bufio.NewScanner( os.Stdin )

	outer: // Labeling For Loop
		for input.Scan() {
			var ints []int

			for _, s := range strings.Fields( input.Text() ) {
				x, err := strconv.ParseInt( s, 10, 64 )
				
				if err != nil {
					fmt.Fprintln( os.Stderr, err )
					continue outer // Jumping To Label outer
				}
				ints = append( ints, int(x) )
			}

			fmt.Printf( "%v\n", ints )
			reverse( ints  )
			fmt.Printf( "%v\n", ints )
		}
}

// NOTE : Type Ctrl+D For EoF

//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

// Simulating 2 Dimentional Arrays Using Slices
func playWith2DimentionalData() {

	twoD := make( [][]int, 3 )

	for i := 0 ;  i < 3 ;  i++ {
		innerLen := i + 1

		twoD[i] = make( []int, innerLen ) 

		for j := 0 ; j < innerLen ; j++ {
			twoD[i][j] = i + j
		}
	}

	fmt.Println("2 Dimentional Array: ", twoD )
}


//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

// Conceptual Example Of Slice's append Function Internal Working
//		Conceptual Example Of Dynamic Array Implementation Using Slices
func appendInt( x []int, y int ) []int {
	var z []int

	zlen := len(x) + 1
	if zlen <= cap(x) {
		z = x[ : zlen ]
	} else { // Underlining Array Is Full
		// When Array Is Full, Allocate A New Array
		//	To Append Additional Data
		zcap := zlen
		if zcap < 2 * len(x) {
			zcap = 2 * len(x) 	// Pool Size Increased
		}
		
		z = make( []int, zlen, zcap )
		copy(z, x)
	}

	z[ len( x ) ] = y
	return z
}

func playWithAppendInt() {
	var x, y []int

	for i := 0 ; i < 10 ; i++ {
		y = appendInt(x, i)
		fmt.Printf( " %d Capacity=%d \t %v \n", i, cap(y), y )
		x = y
	}
}


//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

// Varidiac Functions With Varidiac Arguments
// 		Function Which Takes Variable Number Of Arguments
//		Here ... Before Type Means It Takes Variable Number Of Arguments
func summation( numbers ...int ) int {
	fmt.Print( numbers )
	total := 0

	for _, number := range numbers {
		total = total + number 
	}

	return total
}

func playWithSummation() {
	var result int

	result = summation() 
	fmt.Println("\n Result : ", result )

	result = summation( 111 )
	fmt.Println("\n Result : ", result )

	result = summation( 10, 20, 30, 40, 50 )
	fmt.Println("\n Result : ", result )

	result = summation( 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 )
	fmt.Println("\n Result : ", result )

	numbers := []int{ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 }
	result = summation( numbers... )
	fmt.Println("\n Result : ", result )
}


//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!


func appendSlice( x []int, y ...int ) []int {
	var z []int

	zlen := len(x) + len( y )
	if zlen <= cap(x) {
		z = x[ : zlen ]
	} else { // Underlining Array Is Full
		// When Array Is Full, Allocate A New Array
		//	To Append Additional Data
		zcap := zlen
		if zcap < 2 * len(x) {
			zcap = 2 * len(x) 	// Pool Size Increased
		}
		
		z = make( []int, zlen, zcap )
		copy(z, x)
	}
	copy( z[ len(x) : ], y )
	return z
}

func playWithAppendSlices() {
	var x, y []int

	for i := 0 ; i < 10 ; i++ {
		y = appendSlice(x, i)
		fmt.Printf( " %d Capacity=%d \t %v \n", i, cap(y), y )
		x = y
	}
	fmt.Println( x )

	x = appendSlice(x , 10, 20, 30 )
	fmt.Println( x )

	x = appendSlice(x , 11, 22, 33, 44, 55, 66 )
	fmt.Println( x )

	numebrs := []int{ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 }
	x = appendSlice( x, numebrs... )
	fmt.Println( x )	
}

//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func filterEmpty( strings []string ) []string {
	i := 0
	for _, s := range strings {
		if s != "" {
			strings[i] = s
			i++
		}
	}
	return strings[ : i ]
}

func filterEmptyAgain( strings []string ) []string {
	out := strings[ : 0 ] // Zero Length Slice Of Original
	for _, s := range strings {
		if s != "" {
			out = append( out, s )
		}
	}
	return out
}

func playWithNonEmpty() {
	data := []string{ "one", "", "two", "ding", "", "ting" }
	fmt.Printf("%q \n", data)	
	filteredData := filterEmpty( data )
	fmt.Printf("%q \n", filteredData )

	dataAgain := []string{ "111", "", "", "9999", "", "Data", "" }
	fmt.Printf("%q \n", dataAgain)	
	filteredDataAgain := filterEmptyAgain( dataAgain )	
	fmt.Printf("%q \n", filteredDataAgain )
}

//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func playWithMaps() {
	m := make( map[string]int )

	m["k1"] = 7
	m["k2"] = 13

	fmt.Println("Map: ", m)

	v1 := m["k1"]
	fmt.Println("Map Key Value: ", v1)

	fmt.Println("Map Length :", len( m ) )
	delete(m, "k2")
	fmt.Println("Map: ", m)

	value, status := m["k2"]	
	fmt.Println("Map Key Value: ", value, status )

	mm := map[string]int{ "foo" : 1, "bar" : 2 }
	fmt.Println("Map: ", mm)
}

//___________________________________________________________________

// HOME WORK

func removeDuplicates() {
	seen := make( map[string]bool ) // a set of strings
	input := bufio.NewScanner( os.Stdin )

	for input.Scan() {
		line := input.Text()
		if !seen[line] {
			seen[line] = true
			// fmt.Println(line)
		}
	}

	if err := input.Err(); err != nil {
		fmt.Fprintf(os.Stderr, "removeDuplicates: %v\n", err)
		os.Exit(1)
	}

	fmt.Println( seen )	
}

//___________________________________________________________________

// HOME WORK
// Test Input
// 		Hello Hello Hello Hello Hello 早上好

func countUnicodeCharacters() {
	counts := make(map[rune]int)    // counts of Unicode characters
	var utflen [utf8.UTFMax + 1]int // count of lengths of UTF-8 encodings
	invalid := 0                    // count of invalid UTF-8 characters

	in := bufio.NewReader(os.Stdin)
	for {
		r, n, err := in.ReadRune() // returns rune, nbytes, error
		if err == io.EOF {
			break
		}
		if err != nil {
			fmt.Fprintf(os.Stderr, "charcount: %v\n", err)
			os.Exit(1)
		}
		if r == unicode.ReplacementChar && n == 1 {
			invalid++
			continue
		}
		counts[r]++
		utflen[n]++
	}
	fmt.Printf("rune\tcount\n")
	for c, n := range counts {
		fmt.Printf("%q\t%d\n", c, n)
	}
	fmt.Print("\nlen\tcount\n")
	for i, n := range utflen {
		if i > 0 {
			fmt.Printf("%d\t%d\n", i, n)
		}
	}
	if invalid > 0 {
		fmt.Printf("\n%d invalid UTF-8 characters\n", invalid)
	}
}


//___________________________________________________________________
//
//						GO STRUCT
//___________________________________________________________________



//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

// HOME WORK 
type Circle struct {
	X, Y, Radius int 
}

type Wheel struct {
	X, Y, Radius, Spokes int
}

func playWithCircleAndWheel() {
	var c Circle
	c.X = 10 
	c.Y = 20
	c.Radius = 50

	fmt.Println("Circle :", c )

	var w Wheel
	w.X = 11 
	w.Y = 22
	w.Radius = 55
	w.Spokes = 24

	fmt.Println("Wheel :", w )
}


//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!


type Point1 struct {
	X int
	Y int
}

type Circle1 struct {
	Center Point1 
	Radius int 
}

type Wheel1 struct {
	Circle Circle1
	Spokes int
}

func playWithCircleAndWheel1() {
	var c Circle1
	c.Center.X = 10 
	c.Center.Y = 20
	c.Radius = 50

	fmt.Println("Circle1 :", c )

	var w Wheel1
	w.Circle.Center.X = 11 
	w.Circle.Center.Y = 22
	w.Circle.Radius = 55
	w.Spokes = 24

	fmt.Println("Wheel1 :", w )
}


//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

// struct Creates Associative Types
//		Type Of Types
type Point struct {
	X int 
	Y int
}

func ScalePoint( point Point, factor  int) Point {
	return Point{ point.X * factor, point.Y * factor }
}

func AddPoint( point1 Point, point2 Point ) Point {
	return Point{ point1.X + point2.X , point1.Y +point2.Y }
}

func playWithPointType() {
	point1 := Point{ 10, 20 }
	point2 := Point{ 100, 200 }
	point3 := Point{ 10, 20 }

	fmt.Println( "point1 : ", point1 )
	fmt.Println( "point2 : ", point2 )
	fmt.Println( "point3 : ", point3 )

	fmt.Println( point1.X == point2.X && point1.Y == point2.Y )
	fmt.Println( point1.X == point3.X && point1.Y == point3.Y )

	// Equality Works For struct Type Also.
	//		It Will Compare Members Of struct
	fmt.Println( "point1 == point2 : ", point1 == point2 )
	fmt.Println( "point1 == point3 : ", point1 == point3 )

	fmt.Println( "point1 *  5 : ", ScalePoint( point1, 5 )  )
	fmt.Println( "point2 * 10 : ", ScalePoint( point2, 10 ) )
	fmt.Println( "point3 *  2 : ", ScalePoint( point3, 2 ) )

	point4 := AddPoint( point1, point2 )
	fmt.Println( "point4 : ", point4 )

	point5 := AddPoint( point1, point3 )
	fmt.Println( "point5 : ", point5 )
}



//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func main() {
	fmt.Println("\nFunction : playWithDefaultInitialValues")
	playWithDefaultInitialValues()

	fmt.Println("\nFunction : playWithArrays")
	playWithArrays()

	fmt.Println("\nFunction : playWithChangeArrays")
	playWithChangeArrays()

	fmt.Println("\nFunction : playWithSlices")
	playWithSlices()

	fmt.Println("\nFunction : playWithArrayAndSlices")
	playWithArrayAndSlices()

	fmt.Println("\nFunction : playWithSlicesFunctions")
	playWithSlicesFunctions()

	// fmt.Println("\nFunction : playWithReadingInputs")
	// playWithReadingInputs()

	fmt.Println("\nFunction : playWith2DimentionalData")
	playWith2DimentionalData()

	fmt.Println("\nFunction : playWithAppendInt")
	playWithAppendInt()

	fmt.Println("\nFunction : playWithSummation")	
	playWithSummation()

	fmt.Println("\nFunction : playWithAppendSlices")
	playWithAppendSlices()

	fmt.Println("\nFunction : playWithNonEmpty")
	playWithNonEmpty()

	fmt.Println("\nFunction : playWithMaps")
	playWithMaps()

	//fmt.Println("\nFunction : removeDuplicates")
	//removeDuplicates()

	// fmt.Println("\nFunction : countUnicodeCharacters")
	// countUnicodeCharacters()

	fmt.Println("\nFunction : playWithCircleAndWheel")
	playWithCircleAndWheel()

	fmt.Println("\nFunction : playWithCircleAndWheel1")
	playWithCircleAndWheel1()

	fmt.Println("\nFunction : playWithPointType")
	playWithPointType()
	
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")	
	// fmt.Println("\nFunction : ")	
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")	
}

