
#include <stdio.h> 
#include <stdbool.h>
#include <limits.h>


void playWithDataTypes() {
	// Original C =
	// Following Identifiers Are Assigned Garbage Value
	// 		Local Variables Are Automatic In C/C++
	bool c, python, java;

	// Best Practice
	//		Always Initialise Variables/Constants To Legal Value
	int i;

	// What Will Be Output???
	printf("\n%d %d %d %d\n", c, python, java, i);
	// 0 0 0 0

	// false false false 0
}

// Choices Are: 1. CTE, 2. RTE, 3. If Block 4. Else Block
void playWithIfElse() {
	int x = -10;

	// if (expression)
	//		expression Evalutates To Non Zero int Value Than It's True
	//		Otherwise False
	if( x ) { printf("If Block"); }
	else  	{ printf("Else Block"); }
}


// Why C/C++ Designers Selected Following Desing
//		char Doesn;t Have Default Range, It's Platform/Hardware Dependent


void playWithCharType() {
	// Depends On Range Of char Type
	//		Char Range Can Be [0, 255] Unsigned Range Or 
	//		[-128 to 127] Signed Range
	//		char Doesn;t Have Default Range, It's Platform/Hardware Dependent
	char ch = 0; // [-128 to 127 ]

	// int Type Range
	// Signed [ -32768, 32767 ]
	// UnSigned [ 0, 65535 ]
	int i; // Default Signed [ -32768, 32767 ]

	// Output Of Following Loop Is Indeterminate
	// 		Can Be Infinite Loop
	//		or Finite Loop
	// for( ; ch < 255 ; ch++ ) {
	// 	printf("Ch value: %c %d\n", ch, ch);
	// }

	// unsigned char ch1 = 0;
	// for( ; ch1 < 128 ; ch1++ ) {
	// 	printf("Ch1 value: %c %d\n", ch1, ch1);
	// }	
}

void playWithDataTypesAgain() {
	int i = 100;
	long l = 900;

	long ll = l + i;

	printf(" \nResult : %ld", ll);
}

//___________________________________________________


int sum(int x, int y) {
	return x + y;
}

void playWithSum() {
	int x = 2147483647;
	int y = 2;

	int z = x + y;
	printf( "\nResult : %d\n", z );

	int xx = -2147483647;
	int yy = -2;

	int zz = xx + yy;
	printf( "Result : %d\n", zz );

}

// Function : playWithSum
// Result : -2147483647
// Result : 2147483647

//___________________________________________________


// Following Code Is Platform Independent!

//
// Type Safe Code
//		Repspecting Type Definition Like God!
signed int summation(signed int si_a, signed int si_b) {
	  signed int sum = 0;
	  if (((si_b > 0) && (si_a > (INT_MAX - si_b))) ||
	      ((si_b < 0) && (si_a < (INT_MIN - si_b)))) {

		    printf("\nCan't Calculate Sum For Given Values");
	  
	  } else {
		    sum = si_a + si_b;
		  	return sum;
	  }
}

//___________________________________________________

// Design Principle C/C++
//		You Should Not Pay For It! If You Are Not Using It!

void playWithStrings() {
	// There Is No String Type In C
	// String Value Starts With " And Ends With "
	// String Is Sequence Of ASCII Characters
	// In C
	//		String Follows ASCII Coding

	char greeting[] = "Good Morning!";	
	char *greetingAgain = "Good Morning!";

	printf("\nGreeting : %s", greeting );

	for ( int i = 0 ;  greeting[i] != '\0' ; i++ ) {
		printf("\nGreeting Character: %c", greeting[i] );
	}
}


//___________________________________________________


void playWithArrays() {

	// TempLen = 3
	int a[3];

	for ( int i = 0 ; i < 3 ; i++ ) {
		printf("At index: %d value: %d\n", i, a[i] );
	}

	// Developer's Responsibility
	// if ( index  < TempLen && index > 0 ) { 
	// 	a[ index ]
	// }
	printf("At index: %d value: %d\n", 3, a[3] );	

	// aa := [2]int{ 10, 20 }
	// bb := [...]int{ 10, 20 }
	// cc := [2]int{ 10, 30 }

	// fmt.Println( aa == bb, aa == cc, bb == cc )

	int aa[2] = { 10, 20 };
	int bb[]  = { 10, 20 };
	int cc[2] = { 10, 30 };

	printf(" %d %d %d ", aa == bb, aa == cc, bb == cc );
}

// CTE
// RTE 

//___________________________________________________

void playWithPointers() {
	int a = 20;

	// ptr is Variable Which Stores Address Af a
	int *ptr = &a ; 

	printf("\na Value: %d \na Address: %p\n Value At Address: %d\n", a, ptr, *ptr);
}

//___________________________________________________


void doChange0(int *ptr) {
        int b = 30;
        *ptr = 999;
	    ptr = &b;
        b = b + 50;
}

void doChange1(int **ptr) {
        int b = 30;
        **ptr = 999;
        *ptr = &b;
        b = b + 50;
}

int playWithPointersAgain() {
        int a = 20;
        int *ptr = &a;
        // ptr is Pointer/Address/Reference
        //      Passing The Reference OF
        //              Pass By Reference
        //              Changes Should Reflect Back main Function

        // Case I       
        //      ptr Is Passed By Value
        //      a Is Passed By Reference   

        doChange0( ptr );
                    
        // Case II      
        //      ptr Is Passed By Reference
        //      a Is Passed By Reference               
        doChange1( &ptr );
        printf("\n Output: %d\n", 
                        *ptr);
        printf("\n Output: %d\n", 
                        a);


}


//___________________________________________________

// In C
//		Array Name Is Reference OF Contigous Memory Location
///		Arrays In C Are Pass By Reference

void doChangeArray0(int a[], int len) {
	for ( int i = 0 ; i < len ; i++ ) {
		a[i] = 888;
	}
}

void doChangeArray1(int *bptr, int len) {
	for ( int i = 0 ; i < len ; i++ ) {
		bptr[i] = 999;
	}
}

void playWithArraysAgain() {
	int a[5] = { 10, 20, 30, 40, 50 };
	int len = 5;
	
	printf("\nArray Before doChangeArray");
	for ( int i = 0 ; i < len ; i++ ) {
		printf("\nAt index: %d value: %d", i, a[i]);
	}

	doChangeArray0( a, len );

	printf("\nArray After doChangeArray");
	for ( int i = 0 ; i < len ; i++ ) {
		printf("\nAt index: %d value: %d", i, a[i]);
	}


	int b[5] = { 10, 20, 30, 40, 50 };

	printf("\nArray Before doChangeArray");
	for ( int i = 0 ; i < len ; i++ ) {
		printf("\nAt index: %d value: %d", i, b[i]);
	}

	doChangeArray1( b, len );

	printf("\nArray After doChangeArray");
	for ( int i = 0 ; i < len ; i++ ) {
		printf("\nAt index: %d value: %d", i, b[i]);
	}

}

// Function : playWithArraysAgain
// Array Before doChangeArray
// At index: 0 value: 10
// At index: 1 value: 20
// At index: 2 value: 30
// At index: 3 value: 40
// At index: 4 value: 50
// Array After doChangeArray
// At index: 0 value: 888
// At index: 1 value: 888
// At index: 2 value: 888
// At index: 3 value: 888
// At index: 4 value: 888
//___________________________________________________
//___________________________________________________
//___________________________________________________
//___________________________________________________

int main() {
	printf("\nFunction : playWithDataTypes");
	playWithDataTypes();

	printf("\nFunction : playWithIfElse");
	playWithIfElse();

	printf("\nFunction : playWithCharType");
	playWithCharType();

	printf("\nFunction : playWithDataTypesAgain");
	playWithDataTypesAgain();

	printf("\nFunction : playWithSum");
	playWithSum();

	printf("\nFunction : playWithStrings");
	playWithStrings();

	printf("\n\nFunction : playWithArrays\n");
	playWithArrays();

	printf("\nFunction : playWithPointers");
	playWithPointers();

	printf("\nFunction : playWithPointersAgain");
	playWithPointersAgain();

	printf("\nFunction : playWithArraysAgain");
	playWithArraysAgain();

	// printf("\nFunction : ");
	// printf("\nFunction : ");
	// printf("\nFunction : ");
	// printf("\nFunction : ");
	// printf("\nFunction : ");
	// printf("\nFunction : ");
}

