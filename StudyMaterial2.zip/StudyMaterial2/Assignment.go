
_____________________________________________________________

DAY 01 : ASSIGENMENTS
_____________________________________________________________

	READING ASSIGNMENT
		Recommended By Trainer
		The C Programming Language, 2nd Edition,
			By Kernigham and Dennis Ritchie

	PHASE I : 
		1. ARRAYS AND POINTERS [ MUST MUST ]

	PHASE II : 
		1. FIRST 6 CHAPTERS

_____________________________________________________________

DAY 02 :
_____________________________________________________________


_____________________________________________________________

DAY 03 :
_____________________________________________________________

	READING ASSIGNMENT
		Recommended By Trainer
		The C Programming Language, 2nd Edition,
			By Kernigham and Dennis Ritchie

	PHASE I : 
		1. ARRAYS AND POINTERS [ MUST MUST ]

_____________________________________________________________

DAY 04 :
_____________________________________________________________


_____________________________________________________________

DAY 05 :
_____________________________________________________________


