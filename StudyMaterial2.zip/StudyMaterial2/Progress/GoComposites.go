
package main

import (
	"fmt"
)

//___________________________________________________________________


func playWithDefaultInitialValues() {
	var a int
	var i8 int8
	var ui8 uint8

	var f1 float32
	var f2 float64

	var s string

	var c1 complex64 
	var c2 complex128

	var b bool

	fmt.Printf("%d %d %d\n", a, i8, ui8)
	fmt.Printf("%f %f\n", f1, f2)	
	fmt.Printf("%s \n", s)	
	fmt.Printf("%v %v", c1, c2)	
	fmt.Printf("%t \n", b)	
}

// Function : playWithDefaultInitialValues
// 0 0 0
// 0.000000 0.000000
 
// (0+0i) (0+0i)false 

//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func playWithArrays() {
	// Creating Array of 2 ints
	//		Index Starts From 0 Till len - 1 i.e. [0, len) i.e. [0, len - 1]
	//		All Elements Of Array Intialised To Zeros Of Type

	var a [3]int

	// List Of Tuples : (0, member0), (1, member1), (2, member2)...
	//		Tuple Getting Upacked To Two Identifiers index And value
	for index, value := range a {
		fmt.Printf("At index: %d value: %d\n", index, value)
	}

	fmt.Println( a[0] )
	fmt.Println( a[1] )
	fmt.Println( a[ len( a ) - 1 ] )

	// Compile Time Error : invalid argument: array index 3 out of bounds [0:3]
	// fmt.Println( a[ len( a ) ] ) 
	// _ Means Identifier Which You Wnat To Ignore
	for _, value := range a {
		fmt.Printf("value: %d\n", value)
	}

	var q [5]int = [5]int{ 10, 20, 30, 40, 50 }
	var r [5]int = [5]int{ 10, 20, 30 }

	fmt.Println("Array Length : ", len(q) )
	for index, value := range q {
		fmt.Printf("At index: %d value: %d\n", index, value)
	}

	fmt.Println("Array Length : ", len(r) )
	for index, value := range r {
		fmt.Printf("At index: %d value: %d\n", index, value)
	}

	s := [...]int{ 10, 20, 100, 111 }
	fmt.Println("Array Length : ", len(s) )
	fmt.Printf( "Data Type : %T \n", s )

	for index, value := range s {
		fmt.Printf("At index: %d value: %d\n", index, value)
	}

	some := [3]int { 100, 200, 300 }
	fmt.Printf( "Data Type : %T \n", some )

	someAgain := [...]int{ 99 : - 1 }
	fmt.Println("Array Length : ", len( someAgain ) )
	fmt.Printf( "Data Type : %T \n", someAgain )

	for index, value := range someAgain {
		fmt.Printf("At index: %d value: %d\n", index, value)
	}

	aa := [2]int{ 10, 20 }
	bb := [...]int{ 10, 20 }
	cc := [2]int{ 10, 30 }

	fmt.Println( aa == bb, aa == cc, bb == cc )
	// true false false

	dd := [3]int{ 10, 30 }
	fmt.Println( dd )
	// Compilation Error: 
	// 	invalid operation: aa == dd (mismatched types [2]int and [3]int)
	// fmt.Println( aa == dd )
}

//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

type Flags uint

const ( // STATUS BITs ARE DEFINED AS FOLLOWS
    FlagUp Flags = 1 << iota // is up
	FlagBroadcast		 	 // supports broadcast access capability
	FlagLoopback             // is a loopback interface
	FlagPointToPoint         // belongs to a point-to-point link
	FlagMulticast            // supports multicast access capability
)

func IsUp(v Flags) bool     { return v & FlagUp == FlagUp } // & (bitwise AND)
func TurnDown(v *Flags)     { *v &^= FlagUp }   // &^ (AND NOT): This is a bit clear operator.
func SetBroadcast(v *Flags) { *v |= FlagBroadcast } // | (bitwise OR)
func IsCast(v Flags) bool   { return v & (FlagBroadcast | FlagMulticast) != 0 }

func playWithFlags() {
	var v Flags = FlagMulticast | FlagUp
	fmt.Printf("%b %t\n", v, IsUp(v)) // "10001 true"
	
	TurnDown( &v )
	fmt.Printf("%b %t\n", v, IsUp(v)) // "10000 false"
	
	SetBroadcast( &v )
	fmt.Printf("%b %t\n", v, IsUp(v))   // "10010 false"
	fmt.Printf("%b %t\n", v, IsCast(v)) // "10010 true"
}

//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

// In C By Default
//		Arrays Are Pass By Reference
// In Go By Default
//		Arrays Are Pass By Value
func changeArray0( a [5]int ) {
	for i, _ := range a {
		a[i] = 777
	}
	fmt.Println("Inside changeArray0: ", a )
}

//	Implementing Arrays Pass By Reference
// In Go - To Pass Array By Reference
//		Pass Reference/Address To Function Call Using & Operator
//		Function Arguments Must Be Address/Referemce Type	
func changeArray1( a *[5]int ) {
	for i, _ := range a {
		a[i] = 888
	}
	fmt.Println("Inside changeArray1: ", a )
}

// In Go Slices Are Pass By Reference
func changeArray2( slice []int ) {
	for i, _ := range slice {
		slice[i] = 999
	}
	fmt.Println("Inside changeArray2: ", slice )
}

func playWithChangeArrays() {
	var aa [5]int = [5]int{ 10, 20, 30, 40, 50 }

	fmt.Println("Before changeArray0: ", aa )
	changeArray0( aa )
	fmt.Println("After  changeArray0: ", aa )

	var bb [5]int = [5]int{ 10, 20, 30, 40, 50 }
	fmt.Println("Before changeArray1: ", bb )
	changeArray1( &bb )
	fmt.Println("After  changeArray1: ", bb )

	var cc [10]int = [10]int{ 10, 20, 30, 40, 50, 60, 70, 80, 90, 100 }
	fmt.Println("Before changeArray2: ", cc )
	// Slices Are Pass By Reference
	//		Passing Array Slice Of Full Array cc i.e. Index 0 to len - 1 
	changeArray2( cc[ : ] ) 
	fmt.Println("After  changeArray2: ", cc )

	cc = [10]int{ 10, 20, 30, 40, 50, 60, 70, 80, 90, 100 }
	changeArray2( cc[ : 4 ] ) 
	fmt.Println("After  changeArray2: ", cc )

	cc = [10]int{ 10, 20, 30, 40, 50, 60, 70, 80, 90, 100 }
	changeArray2( cc[ 6 :  ] ) 
	fmt.Println("After  changeArray2: ", cc )

	cc = [10]int{ 10, 20, 30, 40, 50, 60, 70, 80, 90, 100 }
	changeArray2( cc[ 3 : 7 ] ) 
	fmt.Println("After  changeArray2: ", cc )

}

//___________________________________________________________________

func playWithSlices() {

	months := [...]string{ 0: "", "Jan", "Feb", "Mar", "Apr", "May", 
						"Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" }
	
	fmt.Println("Months : ", months )

	quater1 := months[ 1 : 4 ]
	quater2 := months[ 4 : 7 ]

	summer := months[ 2 : 7 ]

	fmt.Println("Quater1 :", quater1)
	fmt.Println("Quater2 :", quater2)

	fmt.Println("Summer  :", summer)
}

//___________________________________________________________________


//_____________________________________________________________________________________
// 						
// 									GO SLICES CONCEPTS
//_____________________________________________________________________________________


// Slices represent variable-length sequences whose elements all have the same type. 
// 	A slice type is written []T, where the elements have type T; 
// 		it looks like an array type without a size.

// A slice is a lightweight data structure that gives access to a subsequence (or perhaps all)
// 	 of the elements of an array, which is known as the slice’s underlying array. 

// 	A slice has three components: a pointer, a length, and a capacity. 
// 		The pointer points to the first element of the array that is reachable through the slice, 
// 			which is not necessarily the array’s first element. 
// 		The length is the number of slice elements; it can’t exceed the capacity, 
// 			which is usually the number of elements between 
// 			the start of the slice and the end of the underlying array. 

// 		The built-in functions len and cap return those values.

// The slice operator s[ i : j ], where 0 ≤ i ≤ j ≤ cap(s), 
// 	Creates a new slice that refers to elements i through j-1 of the sequence s, 
// 	which may be an array variable, a pointer to an array, or another slice. 
// 	The resulting slice has j-i elements. 
// 	If i is omitted,it’s 0,and if j isomitted, it’s len(s). 

// 	Thus the slice months[1:13] refers to the whole range of valid months, 
// 	as does the slice months[1:]; the slice months[:] refers to the whole array.


//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
// EXPERIMENT FOLLOWING CODE, MOMENT DONE, PLEASE RAISE YOUR HAND!!!

func main() {
	fmt.Println("\nFunction : playWithDefaultInitialValues")
	playWithDefaultInitialValues()

	fmt.Println("\nFunction : playWithArrays")
	playWithArrays()

	fmt.Println("\nFunction : playWithChangeArrays")
	playWithChangeArrays()

	fmt.Println("\nFunction : playWithSlices")
	playWithSlices()

	// fmt.Println("\nFunction : ")	
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")	
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")	
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")	
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")
	// fmt.Println("\nFunction : ")	
}

