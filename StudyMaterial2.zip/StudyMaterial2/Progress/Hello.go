
// Run Go File
// go run Hello.go

package main

import "fmt"

func main() {
	fmt.Println("Hello World!!!");
}

